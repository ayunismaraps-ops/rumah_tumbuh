"""Tanggal bisnis (Asia/Jakarta). Satu-satunya sumber 'hari ini' agar tes dapat memalsukannya.

Di database, tanggal bisnis disimpan sebagai tengah malam Jakarta dalam UTC
(contoh 2026-11-01T17:00:00.000Z untuk 02/11/2026), sama seperti batas periode.
"""

from datetime import date, datetime, timedelta, timezone

from .auth.period import JAKARTA
from .db import from_db, to_db


def hari_ini() -> date:
    """Tanggal hari ini menurut Asia/Jakarta."""
    return datetime.now(timezone.utc).astimezone(JAKARTA).date()


def date_to_db(value: date) -> str:
    """Ubah tanggal bisnis menjadi teks database."""
    return to_db(datetime(value.year, value.month, value.day, tzinfo=JAKARTA))


def db_to_date(value: str) -> date:
    """Ubah teks database menjadi tanggal bisnis Jakarta."""
    return from_db(value).astimezone(JAKARTA).date()


def format_tanggal(value: date) -> str:
    """Format dd/mm/yyyy."""
    return value.strftime("%d/%m/%Y")


def parse_tanggal(text: str) -> date | None:
    """Baca yyyy-mm-dd (input date) atau dd/mm/yyyy. Mengembalikan None bila tidak valid."""
    text = (text or "").strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def hari_berikutnya(value: date, jumlah: int = 1) -> date:
    """Tanggal setelah `jumlah` hari."""
    return value + timedelta(days=jumlah)
