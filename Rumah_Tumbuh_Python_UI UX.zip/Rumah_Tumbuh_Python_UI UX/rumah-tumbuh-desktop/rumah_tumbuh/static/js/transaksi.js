// Pembantu halaman: tambah baris barang, hitung total, isi contoh penyesuaian, dialog, dan cetak.
// Semua halaman tetap berfungsi tanpa JavaScript (kecuali tombol cetak dan dialog).
(function () {
  function angka(teks) {
    var bersih = String(teks || "").replace(/[^0-9,.]/g, "");
    if (bersih.indexOf(",") >= 0) bersih = bersih.replace(/\./g, "").replace(",", ".");
    var n = parseFloat(bersih);
    return isNaN(n) ? 0 : n;
  }
  function rupiah(n) {
    return "Rp " + Math.round(n).toLocaleString("id-ID");
  }

  var wadah = document.querySelector("[data-items]");
  if (wadah) {
    var tubuh = wadah.querySelector("[data-item-rows]");
    var total = wadah.querySelector("[data-total]");
    var hitung = function () {
      if (!total) return;
      var jumlah = 0;
      tubuh.querySelectorAll("[data-item-row]").forEach(function (baris) {
        var q = baris.querySelector('[name="qty"]');
        var h = baris.querySelector('[name="harga"]');
        var d = baris.querySelector('[name="diskon"]');
        if (q && h) jumlah += Math.round(angka(q.value) * angka(h.value)) - angka(d && d.value);
      });
      total.textContent = "Perkiraan total: " + rupiah(jumlah);
    };
    wadah.addEventListener("input", hitung);
    var tambah = wadah.querySelector("[data-add-row]");
    if (tambah) {
      tambah.addEventListener("click", function () {
        var contoh = tubuh.querySelector("[data-item-row]");
        var salinan = contoh.cloneNode(true);
        salinan.querySelectorAll("input:not([type=hidden])").forEach(function (i) { i.value = ""; });
        salinan.querySelectorAll("select").forEach(function (s) { s.selectedIndex = 0; });
        salinan.querySelectorAll(".field-error").forEach(function (e) { e.remove(); });
        tubuh.appendChild(salinan);
      });
    }
    hitung();
  }

  document.querySelectorAll("[data-templat]").forEach(function (tombol) {
    tombol.addEventListener("click", function () {
      document.getElementById("akun_debit").value = tombol.dataset.debit;
      document.getElementById("akun_kredit").value = tombol.dataset.kredit;
    });
  });

  document.querySelectorAll("[data-open-dialog]").forEach(function (tombol) {
    tombol.addEventListener("click", function () {
      var dialog = document.getElementById(tombol.dataset.openDialog);
      if (dialog && dialog.showModal) dialog.showModal();
    });
  });
  document.querySelectorAll("[data-close-dialog]").forEach(function (tombol) {
    tombol.addEventListener("click", function () { tombol.closest("dialog").close(); });
  });
  document.querySelectorAll("[data-print]").forEach(function (tombol) {
    tombol.addEventListener("click", function () { window.print(); });
  });

  // Cegah kirim ganda: tombol simpan dikunci setelah diklik.
  document.querySelectorAll("form.form-panel").forEach(function (form) {
    form.addEventListener("submit", function () {
      var tombol = form.querySelector('button[type="submit"]');
      if (tombol) { tombol.disabled = true; tombol.textContent = "Menyimpan…"; }
    });
  });
})();
