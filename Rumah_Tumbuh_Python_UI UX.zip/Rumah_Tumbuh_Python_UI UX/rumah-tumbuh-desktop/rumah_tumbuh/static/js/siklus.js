document.querySelectorAll("[data-stock]").forEach((box) => {
  const fields = box.closest(".rt-note").querySelector("[data-stock-fields]");
  const form = box.closest("[data-transaction]");
  const kredit = form?.querySelector('[name="kredit"]');
  const customer = form?.querySelector("[data-customer-field]");
  const customerInput = customer?.querySelector("input");
  function syncStock() {
    const isSale = kredit && ["4110", "4120"].includes(kredit.value);
    fields.hidden = !box.checked;
    fields.querySelectorAll("input,select").forEach((field) => { field.disabled = !box.checked; });
    if (customer) {
      customer.hidden = !isSale;
      customerInput.required = Boolean(isSale);
      customerInput.disabled = !isSale;
    }
  }
  box.addEventListener("change", syncStock);
  kredit?.addEventListener("change", syncStock);
  syncStock();
});
document.querySelectorAll("form[data-confirm]").forEach((form) => {
  form.addEventListener("submit", (event) => {
    if (!window.confirm(form.dataset.confirm)) event.preventDefault();
  });
});
document.querySelectorAll("[data-print]").forEach((button) => {
  button.addEventListener("click", () => window.print());
});
const pdf = document.querySelector("[data-pdf-download]");
if (pdf) pdf.click();
