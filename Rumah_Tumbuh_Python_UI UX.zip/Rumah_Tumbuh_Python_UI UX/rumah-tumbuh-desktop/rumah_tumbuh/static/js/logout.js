// Tombol Keluar: POST same-origin lalu navigasi penuh agar tampilan tidak memakai cache lama.
(function () {
  var wrap = document.querySelector("[data-logout]");
  if (!wrap) return;
  var button = wrap.querySelector("[data-logout-button]");
  var text = wrap.querySelector("[data-logout-text]");
  var locked = false;
  var errorEl = null;
  button.addEventListener("click", function () {
    if (locked) return;
    locked = true;
    button.disabled = true;
    text.textContent = "Keluar…";
    if (errorEl) {
      errorEl.remove();
      errorEl = null;
    }
    fetch("/api/auth/logout", { method: "POST", credentials: "same-origin" })
      .then(function (r) {
        if (!r.ok) throw new Error();
        window.location.assign("/login");
      })
      .catch(function () {
        errorEl = document.createElement("p");
        errorEl.className = "field-error";
        errorEl.setAttribute("role", "alert");
        errorEl.textContent = "Gagal keluar. Coba lagi.";
        wrap.appendChild(errorEl);
        text.textContent = "Keluar";
        button.disabled = false;
        locked = false;
      });
  });
})();
