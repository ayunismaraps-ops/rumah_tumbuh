// Perilaku form login/buat akun: validasi sisi klien (sama dengan server), kirim JSON,
// tampilkan galat per field, cegah kirim ganda, tampil/sembunyi sandi.
(function () {
  var root = document.querySelector("[data-auth-form]");
  if (!root) return;
  var register = root.dataset.mode === "register";
  var form = root.querySelector("[data-form]");
  var submitButton = root.querySelector("[data-submit]");
  var submitText = root.querySelector("[data-submit-text]");
  var names = register ? ["nama", "username", "sandi"] : ["username", "sandi"];
  var inputs = {};
  names.forEach(function (n) {
    inputs[n] = form.querySelector("#" + n);
  });
  var reveal = form.querySelector("[data-reveal]");
  var switchLink = root.querySelector("[data-switch]");
  var switchBusy = root.querySelector("[data-switch-busy]");
  var locked = false;
  var banner = null;

  function validate(values) {
    var errors = {};
    function add(key, message) {
      (errors[key] = errors[key] || []).push(message);
    }
    var username = values.username.trim().toLowerCase();
    if (username.length < 3) add("username", "Username minimal 3 karakter.");
    if (username.length > 32) add("username", "Username maksimal 32 karakter.");
    if (!/^[a-z0-9._]+$/.test(username))
      add("username", "Gunakan huruf, angka, titik, atau garis bawah.");
    if (values.sandi.length < 8) add("sandi", "Sandi minimal 8 karakter.");
    if (new TextEncoder().encode(values.sandi).length > 72)
      add("sandi", "Sandi maksimal 72 byte; kurangi panjang sandi.");
    var nama = (values.nama || "").trim();
    if (register) {
      if (nama.length < 2) add("nama", "Nama minimal 2 karakter.");
      if (nama.length > 80) add("nama", "Nama maksimal 80 karakter.");
      if (!/^[^<>]+$/.test(nama)) add("nama", "Nama tidak boleh mengandung tanda < atau >.");
    }
    var data = { username: username, sandi: values.sandi };
    if (register) data.nama = nama;
    return { errors: errors, data: data };
  }

  function showFields(fields) {
    names.forEach(function (n) {
      var messages = fields[n];
      var has = Boolean(messages && messages.length);
      var help = document.getElementById(n + "-help");
      inputs[n].setAttribute("aria-invalid", has ? "true" : "false");
      document.getElementById(n + "-error").textContent = has ? messages[0] : "";
      var ids = (help ? n + "-help " : "") + (has ? n + "-error" : "");
      if (ids.trim()) inputs[n].setAttribute("aria-describedby", ids.trim());
      else inputs[n].removeAttribute("aria-describedby");
    });
  }

  function showError(message) {
    if (banner) {
      banner.remove();
      banner = null;
    }
    if (!message) return;
    banner = document.createElement("div");
    banner.className = "notice error-notice";
    banner.setAttribute("role", "alert");
    banner.tabIndex = -1;
    banner.textContent = message;
    form.insertBefore(banner, form.firstChild);
  }

  function focusFirst(fields) {
    for (var i = 0; i < names.length; i++) {
      if (fields[names[i]] && fields[names[i]].length) {
        inputs[names[i]].focus();
        return;
      }
    }
    if (banner) banner.focus();
  }

  function setBusy(busy) {
    form.setAttribute("aria-busy", busy ? "true" : "false");
    names.forEach(function (n) {
      inputs[n].disabled = busy;
    });
    if (reveal) reveal.disabled = busy;
    submitButton.disabled = busy;
    submitText.textContent = busy ? submitButton.dataset.busyLabel : submitButton.dataset.label;
    switchLink.hidden = busy;
    switchBusy.hidden = !busy;
  }

  if (reveal) {
    reveal.addEventListener("click", function () {
      var show = inputs.sandi.type === "password";
      inputs.sandi.type = show ? "text" : "password";
      reveal.textContent = show ? "Sembunyikan" : "Lihat";
      reveal.setAttribute("aria-label", show ? "Sembunyikan sandi" : "Tampilkan sandi");
      reveal.setAttribute("aria-pressed", show ? "true" : "false");
    });
  }

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    if (locked) return;
    showError("");
    showFields({});
    var values = {};
    names.forEach(function (n) {
      values[n] = inputs[n].value;
    });
    var result = validate(values);
    if (Object.keys(result.errors).length) {
      showFields(result.errors);
      focusFirst(result.errors);
      return;
    }
    locked = true;
    setBusy(true);
    var mode = root.dataset.mode;
    fetch("/api/auth/" + mode, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(result.data),
      credentials: "same-origin",
    })
      .then(function (response) {
        return response.json().then(function (body) {
          return { ok: response.ok, status: response.status, body: body };
        });
      })
      .then(function (r) {
        if (!r.ok) {
          var fields = r.body.fields || {};
          setBusy(false);
          locked = false;
          showFields(fields);
          showError(r.body.error || "Permintaan gagal. Coba lagi.");
          if (r.status === 401) {
            inputs.sandi.value = "";
            inputs.sandi.type = "password";
            if (reveal) {
              reveal.textContent = "Lihat";
              reveal.setAttribute("aria-label", "Tampilkan sandi");
              reveal.setAttribute("aria-pressed", "false");
            }
            window.history.replaceState(null, "", "/login?error=1");
          }
          focusFirst(fields);
          return;
        }
        window.location.assign("/dashboard");
      })
      .catch(function () {
        setBusy(false);
        locked = false;
        showError("Tidak dapat terhubung. Periksa koneksi lalu coba lagi.");
        focusFirst({});
      });
  });
})();
