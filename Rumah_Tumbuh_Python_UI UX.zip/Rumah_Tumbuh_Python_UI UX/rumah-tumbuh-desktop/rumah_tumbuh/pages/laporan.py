"""Laba rugi, neraca, dan arus kas langsung dari jurnal periode."""
from flask import Blueprint, request

from ..web import get_db, halaman
from . import siklus
from .neraca_saldo import hitung_neraca_saldo, pilih_periode

bp = Blueprint("laporan", __name__)
TABS = {"lr": "Laba Rugi", "nrc": "Neraca", "ak": "Arus Kas"}


def laporan_periode(conn, period_id):
    ns = hitung_neraca_saldo(conn, period_id)
    groups = {n: [] for n in "123456"}
    for row in ns["baris"]:
        kode = row["kode"][0]
        if kode in groups:
            amount = row["debit"] - row["kredit"]
            if kode in "234":
                amount = -amount
            groups[kode].append((row["kode"], row["nama"], amount))
    totals = {key: sum(row[2] for row in rows) for key, rows in groups.items()}
    kas = conn.execute(
        "SELECT COALESCE(SUM(l.debit),0), COALESCE(SUM(l.kredit),0) "
        "FROM JurnalLine l JOIN JurnalUmum j ON j.id=l.jurnalId WHERE j.periodId=? AND l.akunKode IN ('1110','1120')",
        (period_id,)).fetchone()
    laba = totals["4"] - totals["5"] - totals["6"]
    return groups, totals, laba, tuple(kas)


@bp.get("/laporan")
@halaman
def tampil(user):
    conn = get_db()
    periode, _ = pilih_periode(conn, request.args.get("periode"))
    tab = request.args.get("tab", "lr")
    if tab not in TABS:
        tab = "lr"
    laporan = laporan_periode(conn, periode["id"]) if periode else None
    return siklus.tampil("laporan", user, "laporan", "Laporan Keuangan", tabs=TABS, tab=tab,
                         periode=periode, laporan=laporan)
