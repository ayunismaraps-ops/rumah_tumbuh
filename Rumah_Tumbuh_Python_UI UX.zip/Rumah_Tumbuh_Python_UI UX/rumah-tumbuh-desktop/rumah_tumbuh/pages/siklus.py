"""Konteks bersama antarmuka siklus, terpisah dari Dashboard."""
from flask import render_template

from .. import tanggal as tgl
from ..accounting.proses_transaksi import periode_aktif
from ..web import NAV, get_db


def akun():
    return get_db().execute("SELECT * FROM Account ORDER BY kode").fetchall()


def tampil(template, user, aktif, judul, **data):
    period = periode_aktif(get_db())
    tanggal = tgl.hari_ini()
    if period:
        tanggal = min(max(tanggal, tgl.db_to_date(period["tanggalMulai"])), tgl.db_to_date(period["tanggalAkhir"]))
    nav = [(k, ikon, "Invoice" if k == "invoice" else label, href)
           for k, ikon, label, href in NAV if k != "barang"]
    return render_template(f"siklus/{template}.html", user=user, aktif=aktif, title=judul, nav=nav,
                           period=period, tanggal_default=tanggal.isoformat(), **data)
