"""Pemilihan periode aktif dan pembukaan bulan kalender baru."""
import calendar
from datetime import date

from flask import Blueprint, redirect, request, url_for

from .. import tanggal as tgl
from ..accounting.proses_transaksi import periode_aktif
from ..accounting.saldo import daftar_periode
from ..auth.period import BULAN
from ..db import new_id, transaction
from ..web import get_db, halaman
from . import siklus

bp = Blueprint("periode", __name__)


def _tampil(user, error=None, nilai=None):
    conn = get_db()
    semua = daftar_periode(conn)
    aktif = periode_aktif(conn)
    sekarang = tgl.hari_ini()
    terpilih = tgl.db_to_date(aktif["tanggalMulai"]) if aktif else sekarang
    tahun_tahun = set(range(max(1900, sekarang.year - 2), min(9998, sekarang.year + 6) + 1))
    tahun_tahun.update(tgl.db_to_date(p["tanggalMulai"]).year for p in semua)
    isian = nilai or {}
    return siklus.tampil("periode", user, "periode", "Manajemen Periode Akuntansi",
                         semua=semua, bulans=BULAN, tahun_pilihan=sorted(tahun_tahun),
                         bulan_pilihan=isian.get("bulan", terpilih.month),
                         tahun_pilihan_aktif=isian.get("tahun", terpilih.year),
                         error=error, pesan=request.args.get("pesan"))


@bp.get("/periode")
@halaman
def tampil(user):
    return _tampil(user)


@bp.post("/periode")
@halaman
def pilih(user):
    month = request.form.get("bulan", "")
    year = request.form.get("tahun", "")
    try:
        mulai = date(int(year), int(month), 1) if year else date.fromisoformat(month + "-01")
        if not 1900 <= mulai.year <= 9998:
            raise ValueError()
    except ValueError:
        return _tampil(user, "Pilih bulan dan tahun yang valid.", request.form), 400
    conn = get_db()
    nama = f"{BULAN[mulai.month-1]} {mulai.year}"
    akhir = mulai.replace(day=calendar.monthrange(mulai.year, mulai.month)[1])
    mulai_db = tgl.date_to_db(mulai)
    with transaction(conn):
        period = conn.execute("SELECT * FROM Period WHERE tanggalMulai=?", (mulai_db,)).fetchone()
        if period and period["status"] == "DITUTUP":
            return redirect(url_for("penutup.pratinjau", periode=period["id"]))
        conn.execute("UPDATE Period SET status='TERSIMPAN' WHERE status='AKTIF'")
        if period:
            conn.execute("UPDATE Period SET status='AKTIF' WHERE id=?", (period["id"],))
        else:
            conn.execute("INSERT INTO Period(id,nama,tanggalMulai,tanggalAkhir,status) VALUES(?,?,?,?,'AKTIF')",
                         (new_id(), nama, mulai_db, tgl.date_to_db(akhir)))
    return redirect(url_for(".tampil", pesan=f"Periode aktif diubah ke {nama}."))
