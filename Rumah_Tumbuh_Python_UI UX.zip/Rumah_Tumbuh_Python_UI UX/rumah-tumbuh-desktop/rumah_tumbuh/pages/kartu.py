"""Kartu kuantitas dan nilai untuk tiga varietas durian."""
from flask import Blueprint, redirect, request, url_for

from ..accounting.queries import kartu_barang
from ..accounting.referensi import VARIETAS, buat_mutasi, hapus_mutasi, stok_form, tanggal_aktif
from ..accounting.proses_transaksi import periode_aktif
from ..db import transaction
from ..web import get_db, halaman
from . import siklus

bp = Blueprint("kartu", __name__)


def varietas_aktif():
    nama = request.args.get("varietas", VARIETAS[0])
    return nama if nama in VARIETAS else VARIETAS[0]


def _tampil(user, error=None, nilai=None):
    conn = get_db()
    jenis = varietas_aktif()
    barang = conn.execute("SELECT id FROM Barang WHERE kategori='dagang' AND namaKunci=?", (jenis.lower(),)).fetchone()
    rows = kartu_barang(conn, barang[0]) if barang else []
    return siklus.tampil("kartu", user, "kartu", "Kartu Persediaan (3 Jenis Durian)", rows=rows,
                         jenis=jenis, varietas=VARIETAS, error=error, nilai=nilai or {},
                         pesan=request.args.get("pesan"))


@bp.get("/kartu-persediaan")
@halaman
def tampil(user):
    return _tampil(user)


@bp.post("/kartu-persediaan")
@halaman
def tambah(user):
    conn = get_db()
    form = dict(request.form)
    form["varietas"] = varietas_aktif()
    try:
        with transaction(conn):
            _, tanggal = tanggal_aktif(conn, form)
            arah = form.get("arah")
            if arah not in ("masuk", "keluar"):
                raise ValueError("Pilih arah mutasi.")
            ket = form.get("keterangan", "").strip() or f"Stok {arah} manual"
            buat_mutasi(conn, stok_form(conn, form), arah, tanggal, ket)
    except ValueError as error:
        return _tampil(user, str(error), form), 400
    return redirect(url_for(".tampil", varietas=form["varietas"], pesan="Mutasi stok berhasil disimpan."))


@bp.post("/kartu-persediaan/<mutasi_id>/hapus")
@halaman
def hapus(user, mutasi_id):
    conn = get_db()
    try:
        with transaction(conn):
            period = periode_aktif(conn)
            row = conn.execute("SELECT * FROM KartuPersediaan WHERE id=?", (mutasi_id,)).fetchone()
            if not row or not period or not period["tanggalMulai"] <= row["tanggal"] <= period["tanggalAkhir"]:
                raise ValueError("Mutasi harus berasal dari periode aktif.")
            if row["transaksiId"] or row["jurnalId"]:
                raise ValueError("Mutasi ini terhubung ke jurnal. Hapus nomor bukti di Jurnal Umum.")
            hapus_mutasi(conn, [(mutasi_id,)])
    except ValueError as error:
        return _tampil(user, str(error)), 400
    return redirect(url_for(".tampil", varietas=varietas_aktif(), pesan="Mutasi dihapus dan saldo dihitung ulang."))
