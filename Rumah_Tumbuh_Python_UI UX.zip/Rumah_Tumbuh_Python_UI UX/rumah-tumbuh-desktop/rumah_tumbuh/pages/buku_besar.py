"""Buku Besar per akun dengan saldo berjalan dalam periode aktif."""
from flask import Blueprint, request

from ..accounting.proses_transaksi import periode_aktif
from ..web import get_db, halaman
from . import siklus
from .jurnal_umum import daftar_baris

bp = Blueprint("buku_besar", __name__)


@bp.get("/buku-besar")
@halaman
def tampil(user):
    conn = get_db()
    coa = siklus.akun()
    kode = request.args.get("akun", "1110")
    akun = next((a for a in coa if a["kode"] == kode), coa[0] if coa else None)
    period = periode_aktif(conn)
    rows = []
    saldo = 0
    if period and akun:
        for row in daftar_baris(conn, period["id"]):
            if row["akunKode"] != akun["kode"]:
                continue
            net = row["debit"] - row["kredit"]
            saldo += net if akun["posSaldo"] == "DB" else -net
            rows.append({**row, "saldo": saldo})
    return siklus.tampil("buku_besar", user, "buku_besar", "Buku Besar", coa=coa,
                         akun=akun, rows=rows, saldo=saldo)
