"""Pemesanan, posting penjualan dan unduhan invoice PDF."""
from io import BytesIO
from xml.sax.saxutils import escape

from flask import Blueprint, request, send_file
from reportlab.lib import colors
from reportlab.lib.enums import TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from .. import tanggal as tgl
from ..accounting.format import format_qty, format_rupiah
from ..accounting.proses_transaksi import periode_aktif
from ..accounting.queries import detail_transaksi
from ..web import ambil_atau_404, get_db, halaman
from . import siklus

bp = Blueprint("invoice", __name__)
STATUS = {"TRANSFER": "Lunas (Transfer Bank)", "TEMPO": "Tempo (Piutang Usaha)", "TUNAI": "Lunas (Tunai)"}


def _tampil(user, nilai=None, error=None):
    conn = get_db()
    period = periode_aktif(conn)
    rows = conn.execute(
        "SELECT t.*, i.status AS status_invoice, "
        "(SELECT GROUP_CONCAT(b.nama, ', ') FROM TransaksiItem ti JOIN Barang b ON b.id=ti.barangId "
        "WHERE ti.transaksiId=t.id) AS barang, "
        "(SELECT SUM(ti.qty) FROM TransaksiItem ti WHERE ti.transaksiId=t.id) AS qty "
        "FROM Transaksi t LEFT JOIN InvoiceDetail i ON i.transaksiId=t.id "
        "WHERE t.periodId=? AND t.jenis='penjualan' ORDER BY t.tanggal DESC,t.rowid DESC",
        (period["id"] if period else "",))
    invoices = [{**dict(r), "tgl": tgl.db_to_date(r["tanggal"])} for r in rows]
    terbit = request.args.get("terbit")
    terbaru = next((r for r in invoices if r["id"] == terbit), None)
    return siklus.tampil("invoice", user, "invoice", "Invoice", invoices=invoices,
                         status=STATUS, nilai=nilai or {}, error=error, terbaru=terbaru)


@bp.get("/invoice")
@halaman
def daftar(user):
    return _tampil(user)


@bp.get("/invoice/<transaksi_id>")
@halaman
def cetak(user, transaksi_id):
    conn = get_db()
    t = ambil_atau_404(detail_transaksi(conn, transaksi_id))
    ambil_atau_404(t if t["jenis"] == "penjualan" else None)
    no = f"INV-{t['noBukti']}" if t["noBukti"] else f"INV-{t['id']}"
    periode = conn.execute("SELECT nama FROM Period WHERE id = ?", (t["periodId"],)).fetchone()
    nama_periode = periode["nama"] if periode else "-"
    username = user["username"]
    hasil = BytesIO()
    styles = getSampleStyleSheet()
    hijau = colors.HexColor("#1f513b")
    garis = colors.HexColor("#d5e1da")
    pucat = colors.HexColor("#edf5f0")
    normal = styles["Normal"]
    normal.fontName = "Helvetica"
    normal.fontSize = 9
    normal.leading = 13
    normal.textColor = colors.HexColor("#172b23")
    nama_gaya = styles["Heading1"]
    nama_gaya.fontName = "Helvetica-Bold"
    nama_gaya.fontSize = 17
    nama_gaya.leading = 20
    nama_gaya.textColor = colors.white
    sub_gaya = styles["Normal"].clone("InvoiceSubtitle")
    sub_gaya.fontSize = 8
    sub_gaya.leading = 11
    sub_gaya.textColor = colors.white
    invoice_gaya = styles["Heading2"].clone("InvoiceHeading")
    invoice_gaya.fontName = "Helvetica-Bold"
    invoice_gaya.fontSize = 15
    invoice_gaya.leading = 18
    invoice_gaya.textColor = colors.white
    invoice_id_gaya = styles["Normal"].clone("InvoiceId")
    invoice_id_gaya.fontSize = 8
    invoice_id_gaya.textColor = colors.white
    section_gaya = styles["Normal"].clone("InvoiceSection")
    section_gaya.fontName = "Helvetica-Bold"
    section_gaya.fontSize = 8
    section_gaya.textColor = colors.HexColor("#263b31")
    muted_gaya = styles["Normal"].clone("InvoiceMuted")
    muted_gaya.fontSize = 8
    muted_gaya.textColor = colors.HexColor("#52665b")
    right_gaya = styles["Normal"].clone("InvoiceRight")
    right_gaya.alignment = TA_RIGHT
    header_left = [Paragraph(escape(username), nama_gaya),
                   Paragraph("Sistem Informasi Akuntansi &amp; Agribisnis Kebun Durian", sub_gaya)]
    header_right = [Paragraph("INVOICE", invoice_gaya), Paragraph(escape(no), invoice_id_gaya)]
    header = Table([[header_left, header_right]], colWidths=[370, 161])
    header.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), hijau),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (1, 0), (1, 0), "LEFT"),
        ("LEFTPADDING", (0, 0), (-1, -1), 16),
        ("RIGHTPADDING", (0, 0), (-1, -1), 16),
        ("TOPPADDING", (0, 0), (-1, -1), 13),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 13),
    ]))
    label_style = styles["Normal"].clone("InvoiceColumnHead")
    label_style.fontName = "Helvetica-Bold"
    label_style.fontSize = 7.5
    label_style.textColor = hijau
    label_style.leading = 9
    items = [[Paragraph("DESKRIPSI PRODUK / VARIETAS", label_style),
              Paragraph("KUANTITAS", label_style),
              Paragraph("HARGA / KG", label_style),
              Paragraph("SUBTOTAL", label_style)]]
    for i in t["items"]:
        items.append([Paragraph(escape(i["nama"]), normal),
                      f"{format_qty(i['qty'])} {escape(i['satuan'])}",
                      format_rupiah(i["harga"]), Paragraph(f"<b>{format_rupiah(i['subtotal'])}</b>", right_gaya)])
    if not t["items"]:
        items.append([Paragraph(escape(t["keterangan"]), normal), "–", "–",
                      Paragraph(f"<b>{format_rupiah(t['nominal'])}</b>", right_gaya)])
    table = Table(items, colWidths=[237, 85, 94, 115], repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), pucat),
        ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 9),
        ("RIGHTPADDING", (0, 0), (-1, -1), 9),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 11),
        ("TOPPADDING", (0, 0), (-1, -1), 11),
        ("LINEBELOW", (0, 0), (-1, -1), .5, garis),
    ]))
    billing = Table([
        [[Paragraph("DITAGIHKAN KEPADA:", section_gaya),
          Paragraph(escape(t["pihak"] or "Pelanggan"), normal),
          Paragraph(f"Status Pembayaran: {escape(STATUS.get(t['metode'], t['metode']))}", muted_gaya)],
         [Paragraph("TANGGAL INVOICE:", section_gaya),
          Paragraph(t["tanggal"].isoformat(), normal),
          Paragraph(f"Periode: {escape(nama_periode)}", muted_gaya)]]
    ], colWidths=[265.5, 265.5])
    billing.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LINEBELOW", (0, 0), (-1, -1), .5, garis),
    ]))
    total_gaya = styles["Normal"].clone("InvoiceTotal")
    total_gaya.fontName = "Helvetica-Bold"
    total_gaya.fontSize = 10
    total_gaya.textColor = colors.white
    total = Table([[Paragraph("TOTAL TAGIHAN:", total_gaya),
                    Paragraph(format_rupiah(t["nominal"]), total_gaya)]], colWidths=[135, 105])
    total.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), hijau),
        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 11),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 11),
    ]))
    tanda = Table([[Paragraph("Hormat Kami,", normal)],
                   [Spacer(0, 28)],
                   [Paragraph(f"<b>{escape(username)}</b>", normal)]], colWidths=[150])
    tanda.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "LEFT"),
                               ("LEFTPADDING", (0, 0), (-1, -1), 0),
                               ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    footer_style = styles["Normal"].clone("InvoiceFooter")
    footer_style.fontSize = 7.5
    footer_style.textColor = colors.HexColor("#73877b")
    footer = Table([[Paragraph(f"Dokumen ini diterbitkan secara sah oleh Sistem Akuntansi Kebun Durian {escape(username)}.", footer_style)]], colWidths=[531])
    footer.setStyle(TableStyle([("LINEABOVE", (0, 0), (-1, -1), .5, garis),
                                ("TOPPADDING", (0, 0), (-1, -1), 8),
                                ("LEFTPADDING", (0, 0), (-1, -1), 5)]))
    SimpleDocTemplate(hasil, pagesize=A4, rightMargin=32, leftMargin=32,
                      topMargin=38, bottomMargin=32, title=f"Invoice {no}").build([
        header, Spacer(1, 17), billing, Spacer(1, 10), table,
        Spacer(1, 17), Table([["", total]], colWidths=[291, 240]),
        Spacer(1, 20), Table([["", tanda]], colWidths=[291, 240]),
        Spacer(1, 17), footer,
    ])
    hasil.seek(0)
    nama_file = "".join(c for c in no if c.isalnum() or c in "._-")
    return send_file(hasil, mimetype="application/pdf", as_attachment=True, download_name=f"{nama_file or 'invoice'}.pdf")
