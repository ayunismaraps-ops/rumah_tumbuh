"""Ayat Jurnal Penyesuaian dengan pilihan akun debit dan kredit."""
from flask import Blueprint, redirect, request, url_for

from ..accounting.proses_transaksi import periode_aktif
from ..accounting.referensi import simpan_catatan
from ..web import get_db, halaman
from . import siklus
from .jurnal_umum import daftar_baris

bp = Blueprint("penyesuaian", __name__)


def _tampil(user, nilai=None, error=None):
    conn = get_db()
    period = periode_aktif(conn)
    rows = daftar_baris(conn, period["id"], "PENYESUAIAN") if period else []
    return siklus.tampil("penyesuaian", user, "penyesuaian", "Jurnal Penyesuaian (Adjustment)",
                         rows=rows, coa=[a for a in siklus.akun() if a["kode"] != "3130"],
                         nilai=nilai or {}, error=error, pesan=request.args.get("pesan"))


@bp.get("/jurnal-penyesuaian")
@halaman
def form(user):
    return _tampil(user)


@bp.post("/jurnal-penyesuaian")
@halaman
def simpan(user):
    try:
        simpan_catatan(get_db(), user["id"], request.form, "penyesuaian")
    except ValueError as error:
        return _tampil(user, request.form, str(error)), 400
    return redirect(url_for(".form", pesan="Ayat Jurnal Penyesuaian berhasil disimpan."))
