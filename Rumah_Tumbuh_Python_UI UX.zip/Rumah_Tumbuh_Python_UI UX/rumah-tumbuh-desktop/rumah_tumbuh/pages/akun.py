"""Daftar akun, pencarian, dan penambahan COA."""
import re
import sqlite3

from flask import Blueprint, abort, redirect, request, url_for

from ..db import transaction
from ..web import get_db, halaman
from . import siklus

bp = Blueprint("akun", __name__)
AKUN_BAWAAN = frozenset({
    "1110", "1120", "1130", "1140", "1141", "1142", "1143", "1150",
    "1210", "1220", "1221", "1230", "1231", "1240", "1250", "1251",
    "1260", "1261", "1270", "1271", "2110", "2120", "2130", "2140",
    "3110", "3120", "3130", "4110", "4120", "4130", "5110", "5120",
    "5130", "6110", "6120", "6130", "6140", "6150", "6160", "6170",
    "6180", "6190",
})


def _tampil(user, error=None, nilai=None):
    cari = request.args.get("cari", "").strip()
    conn = get_db()
    coa = [dict(row) for row in siklus.akun()]
    terpakai = {row[0] for row in conn.execute("SELECT DISTINCT akunKode FROM JurnalLine")}
    for akun in coa:
        akun["bawaan"] = akun["kode"] in AKUN_BAWAAN
        akun["terpakai"] = akun["kode"] in terpakai
    rows = [r for r in coa if any(cari.casefold() in (r[k] or "").casefold() for k in ("kode", "nama", "golongan"))]
    return siklus.tampil("akun", user, "akun", "Daftar Akun (Chart of Account - COA)",
                         rows=rows, jumlah=len(coa), cari=cari, nilai=nilai or {}, error=error,
                         pesan=request.args.get("pesan"))


@bp.get("/akun")
@halaman
def tampil(user):
    return _tampil(user)


@bp.post("/akun")
@halaman
def tambah(user):
    form = request.form
    kode, nama, golongan = (form.get(k, "").strip() for k in ("kode", "nama", "golongan"))
    pos, lap = form.get("pos"), form.get("laporan")
    if not re.fullmatch(r"[1-6][0-9]{3}", kode) or not nama or len(nama) > 100 or not golongan or len(golongan) > 100:
        return _tampil(user, "Isi kode empat digit (awalan 1–6), nama, dan golongan akun.", form), 400
    if pos not in ("DB", "KR") or lap not in ("NRC", "LR"):
        return _tampil(user, "Pilih sisi normal dan jenis laporan.", form), 400
    try:
        get_db().execute("INSERT INTO Account(kode,nama,posSaldo,posLaporan,golongan) VALUES(?,?,?,?,?)",
                         (kode, nama, pos, lap, golongan))
    except sqlite3.IntegrityError:
        return _tampil(user, "Kode akun sudah terdaftar.", form), 400
    return redirect(url_for(".tampil", pesan=f"Akun {kode} — {nama} berhasil ditambahkan."))


@bp.post("/akun/<kode>/hapus")
@halaman
def hapus(user, kode):
    conn = get_db()
    if kode in AKUN_BAWAAN:
        return redirect(url_for(".tampil", pesan="Akun bawaan aplikasi tidak dapat dihapus."))
    with transaction(conn):
        akun = conn.execute("SELECT kode FROM Account WHERE kode=?", (kode,)).fetchone()
        if akun is None:
            abort(404)
        if conn.execute("SELECT 1 FROM JurnalLine WHERE akunKode=? LIMIT 1", (kode,)).fetchone():
            return redirect(url_for(".tampil", pesan="Akun sudah dipakai di jurnal sehingga tidak dapat dihapus."))
        conn.execute("DELETE FROM Account WHERE kode=?", (kode,))
    return redirect(url_for(".tampil", pesan=f"Akun {kode} berhasil dihapus."))
