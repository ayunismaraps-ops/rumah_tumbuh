"""Catat transaksi melalui tiga formulir referensi."""
from flask import Blueprint, redirect, request, url_for

from .. import tanggal as tgl
from ..accounting.queries import detail_transaksi
from ..accounting.referensi import VARIETAS, simpan_catatan
from ..db import new_id
from ..web import ambil_atau_404, get_db, halaman
from . import siklus

bp = Blueprint("transaksi", __name__)

TABS = {
    "pemasukan": ("Pemasukan", "Input Pemasukan & Penjualan", "Simpan"),
    "pengeluaran": ("Pengeluaran", "Input Pengeluaran & Biaya Kebun", "Simpan"),
    "lainnya": ("Transaksi Lainnya", "Input Modal atau Utang", "Simpan"),
}


def tab_aktif():
    tab = request.args.get("tab", "pemasukan")
    return tab if tab in TABS else "pemasukan"


def _tampil(user, tab, nilai, error=None):
    akun = [a for a in siklus.akun() if a["kode"] != "3130"]
    debit, kredit = akun, akun
    if tab == "pemasukan":
        debit = [a for a in akun if a["kode"] in ("1110", "1120", "1130")]
        kredit = [a for a in akun if a["kode"].startswith("4")]
    elif tab == "pengeluaran":
        debit = [a for a in akun if a["kode"].startswith(("114", "12", "6"))]
        kredit = [a for a in akun if a["kode"] in ("1110", "1120", "2110")]
    return siklus.tampil("transaksi", user, "transaksi", "Catat Transaksi", tab=tab, tabs=TABS,
                         nilai=nilai, error=error, debit=debit, kredit=kredit, varietas=VARIETAS,
                         form_token=nilai.get("form_token") or new_id())


@bp.get("/transaksi")
@halaman
def form(user):
    return _tampil(user, tab_aktif(), {"tanggal": tgl.hari_ini().isoformat()})


@bp.post("/transaksi")
@halaman
def simpan(user):
    tab = tab_aktif()
    try:
        transaksi_id = simpan_catatan(get_db(), user["id"], request.form, tab)
    except ValueError as error:
        return _tampil(user, tab, request.form, str(error)), 400
    transaksi = get_db().execute("SELECT jenis FROM Transaksi WHERE id=?", (transaksi_id,)).fetchone()
    if transaksi and transaksi["jenis"] == "penjualan":
        return redirect(url_for("invoice.daftar", terbit=transaksi_id))
    return redirect(url_for(".berhasil", transaksi_id=transaksi_id))


@bp.get("/transaksi/berhasil/<transaksi_id>")
@halaman
def berhasil(user, transaksi_id):
    detail = ambil_atau_404(detail_transaksi(get_db(), transaksi_id))
    return siklus.tampil("transaksi_berhasil", user, "transaksi", "Transaksi berhasil disimpan", t=detail)
