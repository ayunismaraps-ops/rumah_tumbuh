"""Halaman Dashboard."""

from flask import Blueprint

from ..dashboard import dashboard_data
from ..web import STEPS, get_db, halaman, render_halaman

bp = Blueprint("dashboard", __name__)


@bp.get("/dashboard")
@halaman
def tampil(user):
    data = dashboard_data(get_db())
    return render_halaman("dashboard.html", user, "dashboard", "Dashboard", data=data,
                          period=data["period"] if data else None, steps=STEPS)
