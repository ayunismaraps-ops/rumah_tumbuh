"""Neraca Saldo periode terpilih, dengan pilihan sebelum/sesudah penutup."""
from flask import Blueprint, request

from ..accounting.proses_transaksi import periode_aktif
from ..accounting.saldo import daftar_periode
from ..web import get_db, halaman
from . import siklus

bp = Blueprint("neraca_saldo", __name__)


def pilih_periode(conn, period_id):
    semua = daftar_periode(conn)
    pilihan = next((p for p in semua if p["id"] == period_id), None)
    return pilihan or periode_aktif(conn) or (semua[-1] if semua else None), semua


def hitung_neraca_saldo(conn, period_id, sesudah=False):
    rows = conn.execute(
        "SELECT a.kode,a.nama,a.posSaldo,a.posLaporan,a.golongan,SUM(l.debit) d,SUM(l.kredit) k "
        "FROM JurnalLine l JOIN JurnalUmum j ON j.id=l.jurnalId JOIN Account a ON a.kode=l.akunKode "
        "WHERE j.periodId=? AND (? OR j.jenis!='PENUTUP') GROUP BY a.kode ORDER BY a.kode",
        (period_id, sesudah))
    baris = []
    for row in rows:
        net = row["d"] - row["k"]
        baris.append({**dict(row), "debit": max(net, 0), "kredit": max(-net, 0),
                      "saldo": net if row["posSaldo"] == "DB" else -net})
    return {"baris": baris, "total_debit": sum(r["debit"] for r in baris),
            "total_kredit": sum(r["kredit"] for r in baris)}


@bp.get("/neraca-saldo")
@halaman
def tampil(user):
    conn = get_db()
    periode, _ = pilih_periode(conn, request.args.get("periode"))
    ns = hitung_neraca_saldo(conn, periode["id"]) if periode else None
    return siklus.tampil("neraca", user, "neraca_saldo", "Neraca Saldo", ns=ns, periode=periode)
