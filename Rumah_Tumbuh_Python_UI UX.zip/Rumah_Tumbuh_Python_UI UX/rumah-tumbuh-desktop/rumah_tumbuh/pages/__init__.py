"""Halaman aplikasi. Tiap halaman (jurnal, buku besar, dst.) berada di berkasnya sendiri."""

from importlib import import_module

MODUL = (
    "dashboard", "transaksi", "jurnal_umum", "buku_besar", "neraca_saldo", "penyesuaian",
    "laporan", "penutup", "kartu", "barang", "invoice", "periode", "akun",
)


def daftar_blueprint() -> list:
    """Kumpulkan blueprint dari semua modul halaman."""
    return [import_module(f"{__name__}.{nama}").bp for nama in MODUL]
