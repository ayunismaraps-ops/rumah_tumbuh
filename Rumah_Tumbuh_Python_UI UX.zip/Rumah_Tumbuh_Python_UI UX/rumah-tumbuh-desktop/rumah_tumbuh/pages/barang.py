"""Halaman Barang & Stok: daftar, tambah, ubah. Tidak ada hapus barang."""

from flask import Blueprint, redirect, request

from ..accounting.master_data import BarangError, daftar_barang, tambah_barang, ubah_barang
from ..accounting.transaksi_config import KATEGORI_BANTUAN, KATEGORI_LABEL
from ..web import ambil_atau_404, get_db, halaman, render_halaman

bp = Blueprint("barang", __name__)


def _tampil(user, errors=None, nilai=None, ubah_id=None, status=200):
    cari = (request.args.get("cari") or "").strip()
    kategori = request.args.get("kategori", "")
    html = render_halaman(
        "barang.html", user, "barang", "Barang & Stok", barang=daftar_barang(get_db(), cari, kategori),
        cari=cari, kategori=kategori, kategori_label=KATEGORI_LABEL, kategori_bantuan=KATEGORI_BANTUAN,
        errors=errors or {}, nilai=nilai or {}, ubah_id=ubah_id,
        pesan=request.args.get("pesan", ""),
    )
    return html, status


@bp.get("/barang")
@halaman
def daftar(user):
    return _tampil(user)


@bp.post("/barang/tambah")
@halaman
def tambah(user):
    try:
        tambah_barang(get_db(), request.form)
    except BarangError as error:
        return _tampil(user, error.errors, request.form, status=400)
    return redirect("/barang?pesan=Barang+berhasil+ditambahkan.")


@bp.post("/barang/<barang_id>/ubah")
@halaman
def ubah(user, barang_id):
    ambil_atau_404(get_db().execute("SELECT 1 FROM Barang WHERE id = ?", (barang_id,)).fetchone())
    try:
        ubah_barang(get_db(), barang_id, request.form)
    except BarangError as error:
        return _tampil(user, error.errors, request.form, ubah_id=barang_id, status=400)
    return redirect("/barang?pesan=Perubahan+barang+disimpan.")
