"""Jurnal per periode. Penghapusan berlaku untuk seluruh bukti."""
from flask import Blueprint, redirect, request, url_for

from .. import tanggal as tgl
from ..accounting.referensi import hapus_jurnal
from ..web import get_db, halaman
from . import siklus
from .neraca_saldo import pilih_periode

bp = Blueprint("jurnal_umum", __name__)


def daftar_baris(conn, period_id, jenis=None):
    rows = conn.execute(
        "SELECT j.id,j.nomor,j.tanggal,j.keterangan,j.jenis,l.akunKode,a.nama,l.debit,l.kredit "
        "FROM JurnalUmum j JOIN JurnalLine l ON l.jurnalId=j.id JOIN Account a ON a.kode=l.akunKode "
        "WHERE j.periodId=? AND (? IS NULL OR j.jenis=?) ORDER BY j.tanggal,j.rowid,l.rowid",
        (period_id, jenis, jenis))
    return [{**dict(r), "tanggal": tgl.db_to_date(r["tanggal"])} for r in rows]


def _tampil(user, error=None):
    conn = get_db()
    periode, _ = pilih_periode(conn, request.args.get("periode"))
    rows = daftar_baris(conn, periode["id"]) if periode else []
    fokus = request.args.get("fokus")
    if fokus:
        rows = [r for r in rows if r["nomor"] == fokus]
    return siklus.tampil("jurnal", user, "jurnal", "Jurnal Umum", rows=rows,
                         debit=sum(r["debit"] for r in rows), kredit=sum(r["kredit"] for r in rows),
                         periode=periode, boleh_hapus=periode and periode["status"] == "AKTIF",
                         error=error, pesan=request.args.get("pesan"))


@bp.get("/jurnal-umum")
@halaman
def tampil(user):
    return _tampil(user)


@bp.post("/jurnal-umum/<jurnal_id>/hapus")
@halaman
def hapus(user, jurnal_id):
    try:
        hapus_jurnal(get_db(), jurnal_id)
    except ValueError as error:
        return _tampil(user, str(error)), 400
    return redirect(url_for(".tampil", pesan="Seluruh baris bukti dihapus dan saldo dihitung ulang."))
