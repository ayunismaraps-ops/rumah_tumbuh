"""Jurnal penutup dan neraca saldo setelah penutupan."""
from flask import Blueprint, redirect, request, url_for

from .. import tanggal as tgl
from ..accounting.jurnal_engine import periksa_jurnal
from ..accounting.jurnal_repo import buat_jurnal
from ..accounting.penutup import susun_penutup
from ..accounting.posting import posting_jurnal
from ..accounting.proses_transaksi import periode_aktif
from ..db import transaction
from ..web import get_db, halaman
from . import siklus
from .neraca_saldo import hitung_neraca_saldo, pilih_periode

bp = Blueprint("penutup", __name__)


def _tampil(user, error=None):
    conn = get_db()
    periode, _ = pilih_periode(conn, request.args.get("periode"))
    ns = hitung_neraca_saldo(conn, periode["id"], True) if periode else None
    closed = periode and periode["status"] == "DITUTUP"
    return siklus.tampil("penutup", user, "penutup", "Jurnal Penutup & Neraca Saldo Setelah Penutupan",
                         ns=ns, periode=periode, closed=closed, error=error,
                         pesan=request.args.get("pesan"))


@bp.get("/jurnal-penutup")
@halaman
def pratinjau(user):
    return _tampil(user)


@bp.post("/jurnal-penutup")
@halaman
def tutup(user):
    conn = get_db()
    try:
        with transaction(conn):
            period = periode_aktif(conn)
            if not period or period["id"] != request.form.get("periode"):
                raise ValueError("Pilih periode aktif yang akan ditutup.")
            ns = hitung_neraca_saldo(conn, period["id"])
            baris = susun_penutup(ns["baris"])
            if not baris:
                raise ValueError("Tidak ada saldo pendapatan, HPP, beban, atau prive yang perlu ditutup.")
            periksa_jurnal(baris, {r["kode"] for r in siklus.akun()}, akun_terlarang=set())
            akhir = tgl.db_to_date(period["tanggalAkhir"])
            bukti = f"CLS-{akhir:%Y%m%d}"
            if conn.execute("SELECT 1 FROM JurnalUmum WHERE nomor=?", (bukti,)).fetchone():
                raise ValueError(f"Nomor {bukti} sudah dipakai. Periksa Jurnal Umum.")
            jurnal = buat_jurnal(conn, period["id"], bukti, akhir,
                                 f"Jurnal penutup {period['nama']}", "PENUTUP", baris)
            posting_jurnal(conn, jurnal)
            conn.execute("UPDATE Period SET status='DITUTUP' WHERE id=?", (period["id"],))
    except ValueError as error:
        return _tampil(user, str(error)), 400
    return redirect(url_for(".pratinjau", periode=period["id"], pesan=f"{bukti} berhasil diposting ke Buku Besar."))


@bp.get("/selesai")
@halaman
def selesai(user):
    return redirect(url_for(".pratinjau"))
