"""Pembungkus desktop PySide6 untuk antarmuka HTML lokal Rumah Tumbuh."""
