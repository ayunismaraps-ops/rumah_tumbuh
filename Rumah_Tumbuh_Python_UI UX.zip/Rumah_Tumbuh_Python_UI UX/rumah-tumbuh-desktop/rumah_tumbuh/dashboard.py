from datetime import datetime

from .accounting.saldo import ringkasan_dashboard
from .auth.period import JAKARTA
from .db import from_db


def summarize_balances(lines):
    """Hitung Kas+Bank, pendapatan, beban (termasuk HPP) dan laba dari saldo per akun."""
    kas_bank = pendapatan = beban = 0
    for line in lines:
        kode, debit, kredit = line["akunKode"], line["debit"], line["kredit"]
        if kode in ("1110", "1120"):
            kas_bank += debit - kredit
        if kode.startswith("41"):
            pendapatan += kredit - debit
        if kode.startswith("51") or kode.startswith("61"):
            beban += debit - kredit
    return {
        "kasBank": kas_bank,
        "pendapatan": pendapatan,
        "beban": beban,
        "laba": pendapatan - beban,
    }


def dashboard_data(conn):
    """Ringkasan dashboard periode aktif: saldo dari buku besar, lima transaksi terakhir."""
    data = ringkasan_dashboard(conn)
    if data is None:
        return None
    periode = data["periode"]
    baris = [{"akunKode": r["kode"], "debit": r["debit"], "kredit": r["kredit"]} for r in data["neraca"]["baris"]]
    return {
        "period": {
            "nama": periode["nama"],
            "tanggalMulai": from_db(periode["tanggalMulai"]),
            "tanggalAkhir": from_db(periode["tanggalAkhir"]),
        },
        "totals": summarize_balances(baris),
        "jumlah": data["jumlah"],
        "recent": [{**t, "tanggal": from_db(t["tanggal"])} for t in data["terakhir"]],
    }


def rupiah(value: int) -> str:
    return ("-Rp " if value < 0 else "Rp ") + f"{abs(value):,}".replace(",", ".")


def date_indonesia(value: datetime) -> str:
    return value.astimezone(JAKARTA).strftime("%d/%m/%Y")
