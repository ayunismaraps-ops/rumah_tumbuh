"""Mesin kartu persediaan rata-rata bergerak (murni, tanpa database dan tanpa Flask).

Jumlah dalam seperseribu satuan (int), nilai dalam rupiah bulat (int).
"""

from dataclasses import dataclass

from .format import bagi_bulat_setengah_naik, format_qty


class PersediaanError(ValueError):
    """Mutasi persediaan tidak valid."""


@dataclass(frozen=True)
class SaldoBarang:
    qty: int = 0
    nilai: int = 0


@dataclass(frozen=True)
class MutasiKartu:
    arah: str  # 'masuk' | 'keluar'
    qty: int
    nilai: int
    saldo_qty: int
    saldo_nilai: int


def terapkan_mutasi(
    saldo: SaldoBarang,
    arah: str,
    qty: int,
    nilai_masuk: int | None = None,
    nama: str = "barang",
    satuan: str = "",
) -> tuple[MutasiKartu, SaldoBarang]:
    """Terapkan satu mutasi pada saldo; kembalikan (baris kartu, saldo baru)."""
    if arah not in ("masuk", "keluar"):
        raise PersediaanError("Arah mutasi harus 'masuk' atau 'keluar'.")
    if qty <= 0:
        raise PersediaanError("Jumlah harus lebih dari 0.")
    if arah == "masuk":
        if nilai_masuk is None or nilai_masuk <= 0:
            raise PersediaanError("Nilai barang masuk harus lebih dari 0.")
        baru = SaldoBarang(saldo.qty + qty, saldo.nilai + nilai_masuk)
        return MutasiKartu("masuk", qty, nilai_masuk, baru.qty, baru.nilai), baru
    if qty > saldo.qty:
        raise PersediaanError(f"Stok {nama} tidak cukup (tersedia {format_qty(saldo.qty)} {satuan}".rstrip() + ")")
    if qty == saldo.qty:
        nilai = saldo.nilai
    else:
        nilai = bagi_bulat_setengah_naik(qty * saldo.nilai, saldo.qty)
    baru = SaldoBarang(saldo.qty - qty, saldo.nilai - nilai)
    return MutasiKartu("keluar", qty, nilai, baru.qty, baru.nilai), baru
