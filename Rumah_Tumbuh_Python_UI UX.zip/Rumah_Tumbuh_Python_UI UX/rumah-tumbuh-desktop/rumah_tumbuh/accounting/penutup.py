"""Jurnal Penutup dan pergantian periode."""

from datetime import timedelta

from .. import tanggal as tgl
from ..auth.period import BULAN
from ..db import new_id, to_db, transaction
from .jurnal_engine import BarisJurnal, JurnalError, periksa_jurnal
from .jurnal_repo import buat_jurnal
from .penomoran import ambil_nomor
from .posting import posting_jurnal
from .proses_transaksi import ProsesTransaksiError, periode_aktif
from .saldo import neraca_saldo
from .transaksi_config import AKUN_IKHTISAR, AKUN_MODAL, AKUN_PRIVE


def susun_penutup(baris_neraca: list[dict]) -> list[BarisJurnal]:
    """Susun jurnal penutup dari neraca saldo sebelum penutup (murni).

    1) Tutup akun laba rugi ke Ikhtisar Laba Rugi; 2) pindahkan laba/rugi ke Modal; 3) tutup Prive ke Modal.
    """
    hasil: list[BarisJurnal] = []
    pendapatan = beban = 0
    for r in baris_neraca:
        if r["posLaporan"] != "LR" or r["saldo"] == 0:
            continue
        net = r["saldo"]
        if r["posSaldo"] == "KR":  # pendapatan: saldo kredit ditutup dengan debit
            hasil.append(BarisJurnal(r["kode"], debit=net) if net > 0 else BarisJurnal(r["kode"], kredit=-net))
            pendapatan += net
        else:  # beban: saldo debit ditutup dengan kredit
            hasil.append(BarisJurnal(r["kode"], kredit=net) if net > 0 else BarisJurnal(r["kode"], debit=-net))
            beban += net
    if pendapatan > 0:
        hasil.append(BarisJurnal(AKUN_IKHTISAR, kredit=pendapatan))
    elif pendapatan < 0:
        hasil.append(BarisJurnal(AKUN_IKHTISAR, debit=-pendapatan))
    if beban > 0:
        hasil.append(BarisJurnal(AKUN_IKHTISAR, debit=beban))
    elif beban < 0:
        hasil.append(BarisJurnal(AKUN_IKHTISAR, kredit=-beban))
    laba = pendapatan - beban
    if laba > 0:
        hasil += [BarisJurnal(AKUN_IKHTISAR, debit=laba), BarisJurnal(AKUN_MODAL, kredit=laba)]
    elif laba < 0:
        hasil += [BarisJurnal(AKUN_MODAL, debit=-laba), BarisJurnal(AKUN_IKHTISAR, kredit=-laba)]
    prive = next((r["saldo"] for r in baris_neraca if r["kode"] == AKUN_PRIVE), 0)
    if prive > 0:
        hasil += [BarisJurnal(AKUN_MODAL, debit=prive), BarisJurnal(AKUN_PRIVE, kredit=prive)]
    return hasil


def tutup_periode(conn, user_id: str) -> dict:
    """Posting jurnal penutup, tutup periode aktif, buka periode berikutnya (atomik)."""
    try:
        with transaction(conn):
            periode = periode_aktif(conn)
            if periode is None:
                raise ProsesTransaksiError({"umum": "Tidak ada periode aktif."})
            ns = neraca_saldo(conn, periode["id"])
            baris = susun_penutup(ns["baris"])
            if not baris:
                raise ProsesTransaksiError({"umum": "Tidak ada saldo pendapatan, beban, atau prive yang perlu ditutup."})
            # Ikhtisar hanya boleh dipakai di sini, jadi daftar akun terlarang dikosongkan.
            periksa_jurnal(baris, {r["kode"] for r in conn.execute("SELECT kode FROM Account")}, akun_terlarang=set())
            mulai, akhir = tgl.db_to_date(periode["tanggalMulai"]), tgl.db_to_date(periode["tanggalAkhir"])
            nomor = ambil_nomor(conn, "JP", akhir)
            jurnal_id = buat_jurnal(conn, periode["id"], nomor, akhir,
                                    f"Jurnal penutup {periode['nama']}", "PENUTUP", baris)
            posting_jurnal(conn, jurnal_id)
            conn.execute("UPDATE Period SET status = 'DITUTUP' WHERE id = ?", (periode["id"],))
            hari = (akhir - mulai).days + 1
            baru_mulai = akhir + timedelta(days=1)
            baru_akhir = baru_mulai + timedelta(days=hari - 1)
            nama = f"{BULAN[baru_mulai.month - 1]} {baru_mulai.year}"
            conn.execute(
                "INSERT INTO Period (id, nama, tanggalMulai, tanggalAkhir, status) VALUES (?,?,?,?, 'AKTIF')",
                (new_id(), nama, tgl.date_to_db(baru_mulai), tgl.date_to_db(baru_akhir)),
            )
            return {"nomor": nomor, "periode_lama": periode["nama"], "periode_baru": nama, "jurnal_id": jurnal_id}
    except JurnalError as error:
        raise ProsesTransaksiError({"umum": str(error)}) from error
