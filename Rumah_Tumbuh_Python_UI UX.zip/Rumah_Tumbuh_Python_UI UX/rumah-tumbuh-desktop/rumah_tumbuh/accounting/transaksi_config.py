"""Pemetaan jenis transaksi -> akun. SATU-SATUNYA sumber pemetaan (dipakai form dan mesin jurnal)."""

from dataclasses import dataclass

# cara bayar -> (label, akun)
CARA: dict[str, tuple[str, str]] = {
    "tunai": ("Tunai", "1110"),
    "transfer": ("Transfer bank", "1120"),
    "tempo": ("Tempo (pelanggan bayar nanti)", "1130"),
    "utang": ("Utang (bayar nanti)", "2110"),
    "belum": ("Belum dibayar (jadi utang gaji)", "2120"),
}

AKUN_KAS = "1110"
AKUN_BANK = "1120"
AKUN_PENJUALAN = "4110"
AKUN_HPP = "5110"
AKUN_KERUGIAN = "5120"
AKUN_PERSEDIAAN = "1140"
AKUN_PERLENGKAPAN = "1150"
AKUN_IKHTISAR = "3130"
AKUN_MODAL = "3110"
AKUN_PRIVE = "3120"

# Tidak boleh muncul pada jurnal transaksi otomatis.
AKUN_TERLARANG_UMUM = frozenset({"3130", "6120", "6140", "1221", "1231", "1261"})

KATEGORI_LABEL = {"dagang": "Barang dagang", "perlengkapan": "Perlengkapan kebun"}
KATEGORI_BANTUAN = {
    "dagang": "Barang dagang: hasil panen atau barang yang kamu jual (contoh: Durian Montong).",
    "perlengkapan": "Perlengkapan kebun: pupuk, pestisida, polybag, selang.",
}

TAB_LABEL = {
    "pemasukan": "Pemasukan",
    "pengeluaran": "Pengeluaran",
    "lainnya": "Transaksi lainnya",
}


@dataclass(frozen=True)
class JenisTransaksi:
    kunci: str
    label: str
    tab: str
    prefix: str
    pola: str
    bantuan: str
    cara: tuple[str, ...] = ()
    label_cara: str = "Cara bayar"
    akun_lawan: str | None = None
    akun_pilihan: tuple[str, ...] = ()
    label_akun: str = "Akun"
    kategori_barang: str | None = None
    label_pihak: str | None = None


JENIS: dict[str, JenisTransaksi] = {
    j.kunci: j
    for j in (
        JenisTransaksi("penjualan", "Penjualan barang", "pemasukan", "PJ", "penjualan",
                       "Jual barang dagang. Harga pokok dihitung otomatis dari kartu persediaan.",
                       cara=("tunai", "transfer", "tempo"), label_cara="Cara bayar pembeli",
                       kategori_barang="dagang", label_pihak="Pelanggan"),
        JenisTransaksi("pendapatan_lain", "Pendapatan lain-lain", "pemasukan", "TL", "terima",
                       "Uang masuk di luar penjualan barang.",
                       cara=("tunai", "transfer"), label_cara="Uang diterima di", akun_lawan="4120"),
        JenisTransaksi("pelunasan_piutang", "Terima pelunasan piutang", "pemasukan", "TL", "terima",
                       "Pelanggan membayar tagihan yang tadinya tempo.",
                       cara=("tunai", "transfer"), label_cara="Uang diterima di", akun_lawan="1130",
                       label_pihak="Pelanggan"),
        JenisTransaksi("pembelian_dagang", "Beli barang dagang", "pengeluaran", "PB", "pembelian_barang",
                       "Beli barang untuk dijual lagi. Stok bertambah otomatis.",
                       cara=("tunai", "transfer", "utang"), label_cara="Cara bayar",
                       kategori_barang="dagang", label_pihak="Pemasok"),
        JenisTransaksi("pembelian_perlengkapan", "Beli perlengkapan kebun", "pengeluaran", "PB", "pembelian_barang",
                       "Beli pupuk, pestisida, polybag, dan sejenisnya.",
                       cara=("tunai", "transfer", "utang"), label_cara="Cara bayar",
                       kategori_barang="perlengkapan", label_pihak="Pemasok"),
        JenisTransaksi("pembelian_aset", "Beli aset (alat, gudang, tanah)", "pengeluaran", "PB", "pembelian_aset",
                       "Beli barang tahan lama. Tidak masuk kartu persediaan.",
                       cara=("tunai", "transfer", "utang"), label_cara="Cara bayar",
                       akun_pilihan=("1260", "1220", "1230", "1210"), label_akun="Jenis aset",
                       label_pihak="Pemasok"),
        JenisTransaksi("bayar_beban", "Bayar biaya (gaji, listrik, dll.)", "pengeluaran", "TL", "beban",
                       "Biaya usaha. Gaji boleh dicatat belum dibayar.",
                       cara=("tunai", "transfer", "belum"), label_cara="Dibayar dari",
                       akun_pilihan=("6110", "6130", "6150", "6160"), label_akun="Jenis biaya"),
        JenisTransaksi("bayar_utang_usaha", "Bayar utang usaha", "pengeluaran", "TL", "bayar",
                       "Bayar tagihan ke pemasok.", cara=("tunai", "transfer"), label_cara="Dibayar dari",
                       akun_lawan="2110", label_pihak="Pemasok"),
        JenisTransaksi("bayar_utang_gaji", "Bayar utang gaji", "pengeluaran", "TL", "bayar",
                       "Bayar gaji yang tadinya belum dibayar.", cara=("tunai", "transfer"),
                       label_cara="Dibayar dari", akun_lawan="2120"),
        JenisTransaksi("bayar_angsuran_bank", "Bayar angsuran utang bank", "pengeluaran", "TL", "bayar",
                       "Cicilan pokok pinjaman bank.", cara=("tunai", "transfer"),
                       label_cara="Dibayar dari", akun_lawan="2210"),
        JenisTransaksi("setoran_modal", "Setoran modal", "lainnya", "TL", "terima",
                       "Pemilik menambah modal usaha.", cara=("tunai", "transfer"),
                       label_cara="Uang diterima di", akun_lawan="3110"),
        JenisTransaksi("terima_pinjaman", "Terima pinjaman bank", "lainnya", "TL", "terima",
                       "Pinjaman dari bank masuk ke usaha.", cara=("tunai", "transfer"),
                       label_cara="Uang diterima di", akun_lawan="2210"),
        JenisTransaksi("prive", "Prive (pemilik ambil uang)", "lainnya", "TL", "bayar",
                       "Pemilik mengambil uang usaha untuk keperluan pribadi.",
                       cara=("tunai", "transfer"), label_cara="Diambil dari", akun_lawan="3120"),
        JenisTransaksi("kerugian_persediaan", "Kerugian persediaan (busuk, rusak, hilang)", "lainnya", "TL",
                       "kerugian", "Nilai kerugian dihitung otomatis dari kartu persediaan saat disimpan.",
                       kategori_barang="dagang"),
        JenisTransaksi("pindah_dana", "Pindah dana Kas dan Bank", "lainnya", "TL", "pindah",
                       "Setor tunai ke bank atau tarik tunai dari bank."),
    )
}

ARAH_PINDAH = {
    "kas_ke_bank": ("Setor tunai ke bank (Kas ke Bank)", AKUN_BANK, AKUN_KAS),
    "bank_ke_kas": ("Tarik tunai dari bank (Bank ke Kas)", AKUN_KAS, AKUN_BANK),
}

PREFIX_LABEL = {"PJ": "Penjualan", "PB": "Pembelian", "TL": "Transaksi lainnya"}


def jenis_per_tab() -> dict[str, list[JenisTransaksi]]:
    """Kelompokkan jenis transaksi per tab untuk tampilan."""
    hasil: dict[str, list[JenisTransaksi]] = {t: [] for t in TAB_LABEL}
    for j in JENIS.values():
        hasil[j.tab].append(j)
    return hasil


def akun_cara(cara: str) -> str:
    """Akun untuk cara bayar."""
    return CARA[cara][1]
