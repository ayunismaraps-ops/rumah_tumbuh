"""Mesin jurnal otomatis (murni, tanpa database dan tanpa Flask).

Pemetaan akun diambil dari transaksi_config.py (satu sumber).
"""

from dataclasses import dataclass

from .transaksi_config import (
    AKUN_HPP,
    AKUN_KERUGIAN,
    AKUN_PENJUALAN,
    AKUN_PERLENGKAPAN,
    AKUN_PERSEDIAAN,
    AKUN_TERLARANG_UMUM,
    ARAH_PINDAH,
    JENIS,
    akun_cara,
)


class JurnalError(ValueError):
    """Jurnal tidak dapat disusun atau tidak lolos pemeriksaan."""


@dataclass(frozen=True)
class BarisJurnal:
    akun: str
    debit: int = 0
    kredit: int = 0


def susun_jurnal(jenis: str, detail: dict, total: int, nilai_pokok: int = 0) -> list[BarisJurnal]:
    """Susun baris jurnal untuk satu transaksi.

    `total` = nilai bersih transaksi (setelah diskon). `nilai_pokok` = jumlah nilai keluar kartu.
    """
    if jenis not in JENIS:
        raise JurnalError("Jenis transaksi tidak dikenal.")
    if total <= 0:
        raise JurnalError("Nilai transaksi harus lebih dari 0.")
    j = JENIS[jenis]
    cara = detail.get("cara")
    if j.cara and cara not in j.cara:
        raise JurnalError("Cara bayar tidak valid untuk jenis transaksi ini.")
    lawan = akun_cara(cara) if cara else None

    if j.pola == "penjualan":
        baris = [BarisJurnal(lawan, debit=total), BarisJurnal(AKUN_PENJUALAN, kredit=total)]
        if nilai_pokok > 0:
            baris += [BarisJurnal(AKUN_HPP, debit=nilai_pokok), BarisJurnal(AKUN_PERSEDIAAN, kredit=nilai_pokok)]
        return baris
    if j.pola == "pembelian_barang":
        akun = AKUN_PERSEDIAAN if j.kategori_barang == "dagang" else AKUN_PERLENGKAPAN
        return [BarisJurnal(akun, debit=total), BarisJurnal(lawan, kredit=total)]
    if j.pola == "pembelian_aset":
        akun = detail.get("akun")
        if akun not in j.akun_pilihan:
            raise JurnalError("Jenis aset tidak valid.")
        return [BarisJurnal(akun, debit=total), BarisJurnal(lawan, kredit=total)]
    if j.pola == "terima":
        return [BarisJurnal(lawan, debit=total), BarisJurnal(j.akun_lawan, kredit=total)]
    if j.pola == "bayar":
        return [BarisJurnal(j.akun_lawan, debit=total), BarisJurnal(lawan, kredit=total)]
    if j.pola == "beban":
        akun = detail.get("akun")
        if akun not in j.akun_pilihan:
            raise JurnalError("Jenis biaya tidak valid.")
        if cara == "belum" and akun != "6110":
            raise JurnalError("Hanya beban gaji yang boleh dicatat belum dibayar.")
        return [BarisJurnal(akun, debit=total), BarisJurnal(lawan, kredit=total)]
    if j.pola == "kerugian":
        if nilai_pokok <= 0:
            raise JurnalError("Nilai kerugian persediaan harus lebih dari 0.")
        return [BarisJurnal(AKUN_KERUGIAN, debit=nilai_pokok), BarisJurnal(AKUN_PERSEDIAAN, kredit=nilai_pokok)]
    if j.pola == "pindah":
        arah = detail.get("arah")
        if arah not in ARAH_PINDAH:
            raise JurnalError("Arah pindah dana tidak valid.")
        _, akun_debit, akun_kredit = ARAH_PINDAH[arah]
        return [BarisJurnal(akun_debit, debit=total), BarisJurnal(akun_kredit, kredit=total)]
    raise JurnalError("Pola jurnal tidak dikenal.")


def periksa_jurnal(
    baris: list[BarisJurnal],
    akun_valid: set[str] | None = None,
    akun_terlarang: frozenset[str] | set[str] = AKUN_TERLARANG_UMUM,
) -> list[BarisJurnal]:
    """Periksa invarian jurnal; kembalikan baris yang sama bila lolos, atau lempar JurnalError."""
    if len(baris) < 2:
        raise JurnalError("Jurnal minimal terdiri dari 2 baris.")
    for b in baris:
        if b.debit < 0 or b.kredit < 0:
            raise JurnalError("Debit dan kredit tidak boleh negatif.")
        if (b.debit > 0) == (b.kredit > 0):
            raise JurnalError("Setiap baris jurnal harus berisi tepat satu sisi (debit atau kredit) bernilai lebih dari 0.")
        if akun_valid is not None and b.akun not in akun_valid:
            raise JurnalError(f"Akun {b.akun} tidak terdaftar.")
        if b.akun in akun_terlarang:
            raise JurnalError(f"Akun {b.akun} tidak boleh dipakai pada jurnal ini.")
    if sum(b.debit for b in baris) != sum(b.kredit for b in baris):
        raise JurnalError("Jurnal tidak seimbang: total debit tidak sama dengan total kredit.")
    return baris
