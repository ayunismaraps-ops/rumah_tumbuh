"""Posting jurnal ke buku besar dan perhitungan saldo berjalan.

Saldo berjalan kumulatif per akun menurut sisi normal akun (Account.posSaldo). Urutan baris:
tanggal, lalu urutan pembuatan jurnal, lalu urutan baris. Jika jurnal baru bertanggal lebih awal
dari baris yang sudah ada, saldo berjalan baris yang lebih baru dihitung ulang (satu-satunya
UPDATE yang diizinkan pada buku besar).
"""

from ..db import new_id


class PostingError(Exception):
    """Posting ke buku besar gagal."""


def posting_jurnal(conn, jurnal_id: str) -> int:
    """Salin tiap baris jurnal ke buku besar lalu hitung saldo berjalan. Mengembalikan jumlah baris."""
    baris = conn.execute(
        "SELECT l.id, l.akunKode, l.debit, l.kredit, j.tanggal, j.periodId "
        "FROM JurnalLine l JOIN JurnalUmum j ON j.id = l.jurnalId WHERE j.id = ? ORDER BY l.rowid",
        (jurnal_id,),
    ).fetchall()
    if not baris:
        raise PostingError("Jurnal tidak memiliki baris untuk diposting.")
    akun_terkait = sorted({b["akunKode"] for b in baris})
    for b in baris:
        conn.execute(
            "INSERT INTO BukuBesar (id, jurnalLineId, periodId, akunKode, tanggal, debit, kredit, saldoBerjalan) "
            "VALUES (?,?,?,?,?,?,?,0)",
            (new_id(), b["id"], b["periodId"], b["akunKode"], b["tanggal"], b["debit"], b["kredit"]),
        )
    for akun in akun_terkait:
        hitung_ulang_saldo(conn, akun)
    return len(baris)


def hitung_ulang_saldo(conn, akun: str) -> None:
    """Hitung ulang saldo berjalan seluruh baris satu akun; hanya baris yang berubah yang ditulis."""
    pos = conn.execute("SELECT posSaldo FROM Account WHERE kode = ?", (akun,)).fetchone()
    if pos is None or pos["posSaldo"] not in ("DB", "KR"):
        raise PostingError(f"Akun {akun} tidak memiliki sisi saldo normal.")
    normal_debit = pos["posSaldo"] == "DB"
    rows = conn.execute(
        "SELECT b.id, b.debit, b.kredit, b.saldoBerjalan FROM BukuBesar b "
        "JOIN JurnalLine l ON l.id = b.jurnalLineId JOIN JurnalUmum j ON j.id = l.jurnalId "
        "WHERE b.akunKode = ? ORDER BY b.tanggal, j.rowid, l.rowid",
        (akun,),
    ).fetchall()
    saldo = 0
    for r in rows:
        saldo += (r["debit"] - r["kredit"]) if normal_debit else (r["kredit"] - r["debit"])
        if r["saldoBerjalan"] != saldo:
            conn.execute("UPDATE BukuBesar SET saldoBerjalan = ? WHERE id = ?", (saldo, r["id"]))
