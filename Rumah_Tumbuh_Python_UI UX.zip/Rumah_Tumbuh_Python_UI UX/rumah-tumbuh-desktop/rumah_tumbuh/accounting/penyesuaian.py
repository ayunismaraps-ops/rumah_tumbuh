"""Jurnal penyesuaian (AJP). Koreksi pembukuan dilakukan di sini, bukan dengan mengubah jurnal lama."""

from dataclasses import dataclass
from datetime import date

from .. import tanggal as tgl
from ..db import transaction
from .format import FormatError, format_qty, parse_qty, parse_rupiah
from .jurnal_engine import BarisJurnal, JurnalError, periksa_jurnal
from .jurnal_repo import buat_jurnal
from .kartu_repo import saldo_terakhir, tambah_kartu
from .penomoran import ambil_nomor
from .persediaan_engine import PersediaanError, terapkan_mutasi
from .posting import posting_jurnal
from .proses_transaksi import ProsesTransaksiError, periode_aktif
from .transaksi_config import AKUN_IKHTISAR, AKUN_PERLENGKAPAN, AKUN_PERSEDIAAN

# Akun kontrol persediaan hanya boleh bergerak lewat kartu.
AKUN_KONTROL_KARTU = frozenset({AKUN_PERSEDIAAN, AKUN_PERLENGKAPAN})
AKUN_PEMAKAIAN_PERLENGKAPAN = "6120"
AKUN_TERLARANG_PENYESUAIAN = frozenset({AKUN_IKHTISAR}) | AKUN_KONTROL_KARTU


@dataclass
class InputPenyesuaian:
    tanggal: date
    keterangan: str
    akun_debit: str = ""
    akun_kredit: str = ""
    nominal: int = 0
    barang_id: str = ""
    qty: int = 0


def validasi_penyesuaian(form: dict, akun_valid: set[str]) -> InputPenyesuaian:
    """Periksa isian penyesuaian bebas (Db/Kr dua akun) atau pemakaian perlengkapan (barang + jumlah)."""
    errors: dict[str, str] = {}
    tanggal = tgl.parse_tanggal(form.get("tanggal", ""))
    if tanggal is None:
        errors["tanggal"] = "Isi tanggal dengan benar."
        tanggal = date(1970, 1, 1)
    ket = (form.get("keterangan") or "").strip()
    if len(ket) < 3:
        errors["keterangan"] = "Keterangan wajib diisi (minimal 3 karakter)."
    elif len(ket) > 200:
        errors["keterangan"] = "Keterangan maksimal 200 karakter."
    if form.get("mode") == "pemakaian":
        if not form.get("barang_id"):
            errors["barang_id"] = "Pilih perlengkapan yang dipakai."
        try:
            qty = parse_qty(form.get("qty", ""))
        except FormatError as e:
            errors["qty"] = str(e)
            qty = 0
        if errors:
            raise ProsesTransaksiError(errors)
        return InputPenyesuaian(tanggal, ket, AKUN_PEMAKAIAN_PERLENGKAPAN, AKUN_PERLENGKAPAN, 0,
                                form["barang_id"], qty)
    d, k = (form.get("akun_debit") or "").strip(), (form.get("akun_kredit") or "").strip()
    for nama, kode in (("akun_debit", d), ("akun_kredit", k)):
        if kode not in akun_valid:
            errors[nama] = "Pilih akun."
        elif kode in AKUN_TERLARANG_PENYESUAIAN:
            errors[nama] = ("Akun persediaan dan perlengkapan diubah lewat 'Pemakaian perlengkapan' atau transaksi."
                            if kode in AKUN_KONTROL_KARTU else "Akun ini hanya dipakai jurnal penutup.")
    if d and d == k:
        errors["akun_kredit"] = "Akun debit dan kredit tidak boleh sama."
    try:
        nominal = parse_rupiah(form.get("nominal", ""))
    except FormatError as e:
        errors["nominal"] = str(e)
        nominal = 0
    if errors:
        raise ProsesTransaksiError(errors)
    return InputPenyesuaian(tanggal, ket, d, k, nominal)


def simpan_penyesuaian(conn, data: InputPenyesuaian) -> str:
    """Simpan jurnal penyesuaian dan posting ke buku besar (atomik). Mengembalikan nomor AJP."""
    try:
        with transaction(conn):
            periode = periode_aktif(conn)
            if periode is None:
                raise ProsesTransaksiError({"umum": "Periode aktif belum tersedia."})
            mulai, akhir = tgl.db_to_date(periode["tanggalMulai"]), tgl.db_to_date(periode["tanggalAkhir"])
            if not (mulai <= data.tanggal <= akhir):
                raise ProsesTransaksiError({
                    "tanggal": f"Tanggal harus berada pada periode aktif ({tgl.format_tanggal(mulai)}–{tgl.format_tanggal(akhir)})."})
            nominal = data.nominal
            nomor = ambil_nomor(conn, "AJP", data.tanggal)
            jurnal_id = None
            kartu_baru = None
            if data.barang_id:
                barang = conn.execute(
                    "SELECT id, nama, satuan, kategori, aktif FROM Barang WHERE id = ?", (data.barang_id,)).fetchone()
                if barang is None or barang["kategori"] != "perlengkapan" or not barang["aktif"]:
                    raise ProsesTransaksiError({"barang_id": "Pilih perlengkapan kebun yang aktif."})
                saldo, terakhir, urut = saldo_terakhir(conn, barang["id"])
                if terakhir is not None and data.tanggal < terakhir:
                    raise ProsesTransaksiError({"tanggal": (
                        f"Tanggal tidak boleh lebih awal dari {tgl.format_tanggal(terakhir)}, "
                        f"karena stok {barang['nama']} sudah bergerak pada tanggal itu.")})
                if data.qty > saldo.qty:
                    raise ProsesTransaksiError({"qty": (
                        f"Stok {barang['nama']} tidak cukup (tersedia {format_qty(saldo.qty)} {barang['satuan']}, "
                        f"diminta {format_qty(data.qty)} {barang['satuan']})")})
                mutasi, _ = terapkan_mutasi(saldo, "keluar", data.qty, nama=barang["nama"], satuan=barang["satuan"])
                nominal = mutasi.nilai
                if nominal <= 0:
                    raise ProsesTransaksiError({"qty": "Nilai pemakaian harus lebih dari 0."})
                kartu_baru = (barang["id"], urut + 1, mutasi)
            baris = periksa_jurnal(
                [BarisJurnal(data.akun_debit, debit=nominal), BarisJurnal(data.akun_kredit, kredit=nominal)],
                {r["kode"] for r in conn.execute("SELECT kode FROM Account")}, akun_terlarang={AKUN_IKHTISAR})
            jurnal_id = buat_jurnal(conn, periode["id"], nomor, data.tanggal, data.keterangan, "PENYESUAIAN", baris)
            if kartu_baru:
                tambah_kartu(conn, kartu_baru[0], kartu_baru[1], data.tanggal, kartu_baru[2], "penyesuaian",
                             data.keterangan, jurnal_id=jurnal_id)
            posting_jurnal(conn, jurnal_id)
            return nomor
    except (JurnalError, PersediaanError) as error:
        raise ProsesTransaksiError({"umum": str(error)}) from error
