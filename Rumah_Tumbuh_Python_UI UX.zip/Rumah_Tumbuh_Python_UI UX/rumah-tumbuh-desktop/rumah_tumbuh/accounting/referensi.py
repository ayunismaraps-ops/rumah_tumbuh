"""Pencatatan debit/kredit dan mutasi stok untuk formulir referensi TSX."""
from .. import tanggal as tgl
from ..db import new_id, transaction
from .format import MAKS_UANG, bagi_bulat_setengah_naik, parse_qty, parse_rupiah
from .jurnal_engine import BarisJurnal, periksa_jurnal
from .jurnal_repo import buat_jurnal
from .kartu_repo import tambah_kartu
from .penomoran import ambil_nomor
from .persediaan_engine import MutasiKartu
from .posting import hitung_ulang_saldo, posting_jurnal
from .proses_transaksi import periode_aktif

VARIETAS = ("Musang King", "Bawor", "Montong")


def tanggal_aktif(conn, form):
    period = periode_aktif(conn)
    tanggal = tgl.parse_tanggal(form.get("tanggal", ""))
    if not period or not tanggal or not period["tanggalMulai"] <= tgl.date_to_db(tanggal) <= period["tanggalAkhir"]:
        raise ValueError("Tanggal harus berada dalam periode aktif.")
    return period, tanggal


def pasangan(debit, kredit, nominal):
    if debit == kredit:
        raise ValueError("Pilih akun debit dan kredit yang berbeda.")
    return [BarisJurnal(debit, debit=nominal), BarisJurnal(kredit, kredit=nominal)]


def stok_form(conn, form):
    jenis = form.get("varietas")
    if jenis not in VARIETAS:
        raise ValueError("Pilih varietas durian.")
    barang = conn.execute("SELECT id FROM Barang WHERE kategori='dagang' AND namaKunci=? AND aktif=1",
                          (jenis.lower(),)).fetchone()
    if not barang:
        raise ValueError("Varietas belum tersedia di daftar barang.")
    qty = parse_qty(form.get("qty"))
    harga = parse_rupiah(form.get("harga"))
    nilai = bagi_bulat_setengah_naik(qty * harga, 1000)
    if not 0 < nilai <= MAKS_UANG or qty > MAKS_UANG:
        raise ValueError("Kuantitas atau nilai persediaan di luar batas.")
    return barang["id"], qty, harga, nilai


def barang_form(conn, form):
    """Barang dan kuantitas untuk rincian tagihan tanpa mutasi kartu stok."""
    jenis = form.get("varietas")
    if jenis not in VARIETAS:
        raise ValueError("Pilih varietas durian untuk invoice.")
    barang = conn.execute(
        "SELECT id FROM Barang WHERE kategori='dagang' AND namaKunci=? AND aktif=1",
        (jenis.lower(),),
    ).fetchone()
    if not barang:
        raise ValueError("Varietas belum tersedia di daftar barang.")
    qty = parse_qty(form.get("qty"))
    return barang["id"], qty


def saldo_mutasi(qty, nilai, arah, jumlah, biaya):
    tanda = 1 if arah == "masuk" else -1
    qty, nilai = qty + tanda * jumlah, nilai + tanda * biaya
    if qty < 0 or nilai < 0 or (qty == 0 and nilai != 0):
        raise ValueError("Stok atau nilai persediaan tidak mencukupi. Periksa jumlah dan harga pokok.")
    return qty, nilai


def buat_mutasi(conn, stok, arah, tanggal, ket, transaksi_id=None, jurnal_id=None):
    barang, qty, _, nilai = stok
    baris = conn.execute("SELECT * FROM KartuPersediaan WHERE barangId=? ORDER BY urut DESC LIMIT 1",
                         (barang,)).fetchone()
    if baris and tgl.date_to_db(tanggal) < baris["tanggal"]:
        raise ValueError("Tanggal mutasi harus sama atau setelah mutasi terakhir varietas ini.")
    saldo_qty, saldo_nilai = saldo_mutasi(baris["saldoQty"] if baris else 0,
                                        baris["saldoNilai"] if baris else 0, arah, qty, nilai)
    mutasi = MutasiKartu(arah=arah, qty=qty, nilai=nilai, saldo_qty=saldo_qty, saldo_nilai=saldo_nilai)
    sumber = "penyesuaian" if not transaksi_id else ("pembelian" if arah == "masuk" else "penjualan")
    tambah_kartu(conn, barang, (baris["urut"] if baris else 0) + 1, tanggal,
                 mutasi, sumber, ket, transaksi_id, jurnal_id)


def simpan_catatan(conn, user_id, form, tab):
    """Posting transaksi, jurnal, buku besar dan kartu dalam satu transaksi SQLite."""
    debit, kredit = form.get("debit", ""), form.get("kredit", "")
    ket = form.get("keterangan", "").strip()
    if not ket or len(ket) > 250:
        raise ValueError("Isi keterangan hingga 250 karakter.")
    if tab == "pemasukan" and (debit not in ("1110", "1120", "1130") or not kredit.startswith("4")):
        raise ValueError("Pilih akun penerimaan dan pendapatan.")
    if tab == "pengeluaran" and (not debit.startswith(("114", "12", "6")) or kredit not in ("1110", "1120", "2110")):
        raise ValueError("Pilih akun pengeluaran dan sumber pembayaran.")

    form_token = form.get("form_token", "").strip() or new_id()
    with transaction(conn):
        existing = conn.execute(
            "SELECT id FROM Transaksi WHERE formToken=? AND createdById=?", (form_token, user_id)
        ).fetchone()
        if existing:
            return existing["id"]
        period, tanggal = tanggal_aktif(conn, form)
        jenis = "PENYESUAIAN" if tab == "penyesuaian" else "UMUM"
        prefix = {"pemasukan": "TRX-IN", "pengeluaran": "TRX-OUT", "lainnya": "TRX-OTH", "penyesuaian": "AJP"}[tab]
        no = form.get("bukti", "").strip() or ambil_nomor(conn, prefix, tanggal)
        stok = stok_form(conn, form) if tab == "pemasukan" and form.get("stok") else None
        nominal = parse_rupiah(form.get("nominal"))
        is_sale = tab == "pemasukan" and kredit in ("4110", "4120")
        pelanggan = form.get("pelanggan", "").strip()
        invoice_item = None
        invoice_status = None
        metode = None
        if is_sale:
            if not pelanggan or len(pelanggan) > 100:
                raise ValueError("Isi nama pembeli untuk menerbitkan invoice.")
            metode = {"1110": "TUNAI", "1120": "TRANSFER", "1130": "TEMPO"}[debit]
            invoice_status = {"1110": "Lunas (tunai)", "1120": "Lunas (transfer bank)",
                              "1130": "Belum dibayar (tempo)"}[debit]
            if stok:
                harga_jual = bagi_bulat_setengah_naik(nominal * 1000, stok[1])
                invoice_item = (stok[0], stok[1], harga_jual, nominal)
        baris = pasangan(debit, kredit, nominal)
        hpp = stok[3] if stok and tab == "pemasukan" else None
        if hpp:
            baris += pasangan("5110", "1140", hpp)
        return simpan_baris(
            conn, user_id, period, tanggal, no, ket, tab, jenis, baris, nominal, stok, hpp,
            pihak=pelanggan if is_sale else None, metode=metode, item=invoice_item,
            invoice_status=invoice_status, form_token=form_token,
        )


def simpan_baris(conn, user_id, period, tanggal, no, ket, tab, jenis, baris, nominal,
                 stok=None, hpp=None, pihak=None, metode=None, item=None, invoice_status=None,
                 form_token=None):
    if len(no) > 60:
        raise ValueError("Nomor bukti maksimal 60 karakter.")
    if conn.execute("SELECT 1 FROM JurnalUmum WHERE nomor=? UNION SELECT 1 FROM Transaksi WHERE noBukti=?",
                    (no, no)).fetchone():
        raise ValueError("Nomor bukti sudah dipakai.")
    akun = {r[0] for r in conn.execute("SELECT kode FROM Account")}
    periksa_jurnal(baris, akun, akun_terlarang={"3130"})
    transaksi_id = None
    if jenis == "UMUM":
        transaksi_id = new_id()
        metode = metode or {"1110": "TUNAI", "1120": "TRANSFER", "1130": "TEMPO"}.get(baris[0].akun, "LAINNYA")
        conn.execute(
            "INSERT INTO Transaksi(id,periodId,tanggal,nominal,keterangan,menu,kategori,metode,hpp,"
            "createdById,noBukti,jenis,pihak,formToken) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (transaksi_id, period["id"], tgl.date_to_db(tanggal), nominal, ket, tab, tab, metode,
             hpp, user_id, no, "penjualan" if invoice_status else f"referensi_{tab}", pihak, form_token),
        )
    jurnal_id = buat_jurnal(conn, period["id"], no, tanggal, ket, jenis, baris, transaksi_id)
    posting_jurnal(conn, jurnal_id)
    if stok:
        arah = "keluar" if tab == "pemasukan" else "masuk"
        buat_mutasi(conn, stok, arah, tanggal, ket, transaksi_id, jurnal_id)
    if item:
        barang, qty, harga, total = item
        conn.execute("INSERT INTO TransaksiItem(id,transaksiId,urut,barangId,qty,harga,subtotal) VALUES(?,?,1,?,?,?,?)",
                     (new_id(), transaksi_id, barang, qty, harga, total))
    if invoice_status:
        conn.execute("INSERT INTO InvoiceDetail VALUES(?,?)", (transaksi_id, invoice_status))
    return transaksi_id


def hapus_jurnal(conn, jurnal_id):
    with transaction(conn):
        period = periode_aktif(conn)
        j = conn.execute("SELECT * FROM JurnalUmum WHERE id=? AND periodId=?",
                         (jurnal_id, period["id"] if period else "")).fetchone()
        if not j or j["jenis"] == "PENUTUP":
            raise ValueError("Hanya jurnal periode aktif yang belum ditutup dapat dihapus.")
        transaksi_id = j["transaksiId"]
        id_jurnal = [jurnal_id]
        if transaksi_id:
            id_jurnal = [r[0] for r in conn.execute("SELECT id FROM JurnalUmum WHERE transaksiId=?", (transaksi_id,))]
        for jid in id_jurnal:
            hapus_mutasi(conn, conn.execute(
                "SELECT id FROM KartuPersediaan WHERE jurnalId=? OR transaksiId=?",
                (jid, transaksi_id)).fetchall())
        akun = set()
        for jid in id_jurnal:
            akun.update(r[0] for r in conn.execute("SELECT akunKode FROM JurnalLine WHERE jurnalId=?", (jid,)))
            conn.execute("DELETE FROM BukuBesar WHERE jurnalLineId IN (SELECT id FROM JurnalLine WHERE jurnalId=?)", (jid,))
            conn.execute("DELETE FROM JurnalLine WHERE jurnalId=?", (jid,))
            conn.execute("DELETE FROM JurnalUmum WHERE id=?", (jid,))
        if transaksi_id:
            conn.execute("DELETE FROM InvoiceDetail WHERE transaksiId=?", (transaksi_id,))
            conn.execute("DELETE FROM TransaksiItem WHERE transaksiId=?", (transaksi_id,))
            conn.execute("DELETE FROM Transaksi WHERE id=?", (transaksi_id,))
        for kode in akun:
            hitung_ulang_saldo(conn, kode)


def hapus_mutasi(conn, ids):
    """Hitung ulang saldo kartu sambil mempertahankan biaya yang dicatat pada setiap mutasi."""
    per_barang = {}
    for target in ids:
        barang = conn.execute("SELECT barangId FROM KartuPersediaan WHERE id=?", (target[0],)).fetchone()
        if barang:
            per_barang.setdefault(barang[0], set()).add(target[0])
    for barang, dihapus in per_barang.items():
        rows = conn.execute("SELECT * FROM KartuPersediaan WHERE barangId=? ORDER BY urut", (barang,)).fetchall()
        conn.execute("DELETE FROM KartuPersediaan WHERE barangId=?", (barang,))
        insert = ("INSERT INTO KartuPersediaan(id,barangId,urut,tanggal,transaksiId,jurnalId,arah,sumber,"
                  "qty,nilai,saldoQty,saldoNilai,keterangan) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)")
        qty = nilai = 0
        for r in rows:
            if r["id"] in dihapus:
                continue
            qty, nilai = saldo_mutasi(qty, nilai, r["arah"], r["qty"], r["nilai"])
            conn.execute(insert, (r["id"], r["barangId"], r["urut"], r["tanggal"], r["transaksiId"],
                                  r["jurnalId"], r["arah"], r["sumber"], r["qty"], r["nilai"], qty, nilai, r["keterangan"]))
