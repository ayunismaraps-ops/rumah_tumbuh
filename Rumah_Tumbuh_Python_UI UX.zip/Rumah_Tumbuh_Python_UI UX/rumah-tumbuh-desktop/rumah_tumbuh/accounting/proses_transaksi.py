"""Pemrosesan otomatis transaksi, ATOMIK dalam satu transaksi database.

Alur (sesuai flowchart): data valid -> kartu persediaan -> jurnal atas transaksi -> jurnal umum
-> posting buku besar -> status 'terjurnal'. Gagal di tahap mana pun = tidak ada yang tersimpan.
Urutan kunci: BEGIN IMMEDIATE mengunci seluruh database untuk penulis lain, jadi tidak ada deadlock
dan dua penjualan serentak diproses bergantian.
"""

import json
import logging
from dataclasses import dataclass

from .. import tanggal as tgl
from ..db import new_id, transaction
from .format import MAKS_UANG, format_qty
from .jurnal_engine import JurnalError, periksa_jurnal, susun_jurnal
from .jurnal_repo import buat_jurnal
from .kartu_repo import saldo_terakhir, tambah_kartu
from .penomoran import ambil_nomor
from .persediaan_engine import PersediaanError, terapkan_mutasi
from .posting import posting_jurnal
from .transaksi_config import JENIS, KATEGORI_LABEL
from .transaksi_validasi import InputTransaksi

log = logging.getLogger("rumah_tumbuh")

PESAN_TAK_TERDUGA = "Transaksi belum dapat diproses. Data Anda tidak berubah. Coba lagi."


class ProsesTransaksiError(Exception):
    """Galat bisnis saat memproses transaksi. `errors` berisi pesan per field (kunci 'umum' = umum)."""

    def __init__(self, errors: dict[str, str]):
        super().__init__("; ".join(errors.values()))
        self.errors = errors


@dataclass(frozen=True)
class HasilProses:
    transaksi_id: str
    jurnal_id: str
    no_bukti: str
    nomor_jurnal: str


def periode_aktif(conn):
    """Periode aktif terbaru (baris) atau None."""
    return conn.execute(
        "SELECT id, nama, tanggalMulai, tanggalAkhir, status FROM Period "
        "WHERE status = 'AKTIF' ORDER BY tanggalMulai DESC LIMIT 1"
    ).fetchone()


def _hasil_dari_db(conn, transaksi_id: str) -> HasilProses:
    row = conn.execute(
        "SELECT t.noBukti, j.id AS jid, j.nomor FROM Transaksi t JOIN JurnalUmum j ON j.transaksiId = t.id "
        "WHERE t.id = ?",
        (transaksi_id,),
    ).fetchone()
    return HasilProses(transaksi_id, row["jid"], row["noBukti"], row["nomor"])


def simpan_transaksi(conn, user_id: str, data: InputTransaksi, form_token: str | None = None) -> HasilProses:
    """Simpan transaksi dan proses otomatis dalam SATU transaksi database."""
    try:
        with transaction(conn):
            if form_token:
                ada = conn.execute("SELECT id FROM Transaksi WHERE formToken = ?", (form_token,)).fetchone()
                if ada:
                    return _hasil_dari_db(conn, ada["id"])
            periode = periode_aktif(conn)
            if periode is None:
                raise ProsesTransaksiError({"umum": "Periode aktif belum tersedia."})
            mulai, akhir = tgl.db_to_date(periode["tanggalMulai"]), tgl.db_to_date(periode["tanggalAkhir"])
            if data.tanggal < mulai or data.tanggal > akhir:
                raise ProsesTransaksiError({
                    "tanggal": f"Tanggal harus berada pada periode aktif ({tgl.format_tanggal(mulai)}–{tgl.format_tanggal(akhir)})."
                })
            if data.tanggal > tgl.hari_ini():
                raise ProsesTransaksiError({"tanggal": "Tanggal tidak boleh di masa depan."})
            j = JENIS[data.jenis]
            if not (1 <= data.nominal <= MAKS_UANG) and j.pola != "kerugian":
                raise ProsesTransaksiError({"nominal": "Nominal harus antara Rp1 dan Rp999.999.999.999."})
            no_bukti = ambil_nomor(conn, j.prefix, data.tanggal)
            keterangan = data.keterangan or f"{j.label} {no_bukti}"
            transaksi_id = new_id()
            detail = {k: v for k, v in (("cara", data.cara), ("akun", data.akun), ("arah", data.arah)) if v}
            conn.execute(
                "INSERT INTO Transaksi (id, periodId, tanggal, nominal, keterangan, menu, kategori, metode, "
                "createdById, noBukti, jenis, pihak, status, detail, formToken) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'tercatat',?,?)",
                (transaksi_id, periode["id"], tgl.date_to_db(data.tanggal), max(data.nominal, 1), keterangan,
                 j.tab.upper(), j.label, data.cara.upper(), user_id, no_bukti, data.jenis, data.pihak or None,
                 json.dumps(detail), form_token or None),
            )
            for urut, it in enumerate(data.items, start=1):
                conn.execute(
                    "INSERT INTO TransaksiItem (id, transaksiId, urut, barangId, qty, harga, diskon, subtotal) "
                    "VALUES (?,?,?,?,?,?,?,?)",
                    (new_id(), transaksi_id, urut, it.barang_id, it.qty, it.harga, it.diskon, it.subtotal),
                )
            return proses_dalam_transaksi(conn, transaksi_id)
    except ProsesTransaksiError:
        raise
    except Exception as error:  # galat tak terduga: rollback sudah terjadi, pesan tanpa data sensitif
        log.error("Pemrosesan transaksi gagal: %s", type(error).__name__)
        raise ProsesTransaksiError({"umum": PESAN_TAK_TERDUGA}) from error


def proses_transaksi(conn, transaksi_id: str) -> HasilProses:
    """Proses transaksi berstatus 'tercatat' dalam transaksi database sendiri (idempoten)."""
    with transaction(conn):
        return proses_dalam_transaksi(conn, transaksi_id)


def proses_dalam_transaksi(conn, transaksi_id: str) -> HasilProses:
    """Inti pemrosesan; dipanggil dari dalam transaksi database yang sudah terbuka."""
    trx = conn.execute("SELECT * FROM Transaksi WHERE id = ?", (transaksi_id,)).fetchone()
    if trx is None:
        raise ProsesTransaksiError({"umum": "Transaksi tidak ditemukan."})
    if trx["status"] == "terjurnal":
        return _hasil_dari_db(conn, transaksi_id)
    j = JENIS[trx["jenis"]]
    detail = json.loads(trx["detail"])
    tanggal = tgl.db_to_date(trx["tanggal"])
    items = conn.execute(
        "SELECT ti.id, ti.urut, ti.barangId, ti.qty, ti.subtotal, b.nama, b.satuan, b.kategori, b.aktif "
        "FROM TransaksiItem ti JOIN Barang b ON b.id = ti.barangId WHERE ti.transaksiId = ? ORDER BY ti.urut",
        (transaksi_id,),
    ).fetchall()

    errors: dict[str, str] = {}
    saldo: dict[str, object] = {}
    urut_kartu: dict[str, int] = {}
    nilai_pokok_total = 0
    pakai_barang = j.kategori_barang is not None
    if pakai_barang and not items:
        raise ProsesTransaksiError({"items": "Tambahkan minimal satu barang."})

    # Pemeriksaan barang dan tanggal terhadap kartu terakhir.
    kebutuhan: dict[str, int] = {}
    for it in items:
        i = it["urut"] - 1
        if not it["aktif"] or it["kategori"] != j.kategori_barang:
            errors[f"item_{i}_barang"] = (
                f"Barang {it['nama']} tidak dapat dipakai pada transaksi ini "
                f"(hanya {KATEGORI_LABEL[j.kategori_barang].lower()} yang aktif)."
            )
            continue
        if it["barangId"] not in saldo:
            s, terakhir, urut = saldo_terakhir(conn, it["barangId"])
            saldo[it["barangId"]], urut_kartu[it["barangId"]] = s, urut
            if terakhir is not None and tanggal < terakhir:
                errors[f"item_{i}_barang"] = (
                    f"Tanggal tidak boleh lebih awal dari {tgl.format_tanggal(terakhir)}, "
                    f"karena stok {it['nama']} sudah bergerak pada tanggal itu."
                )
        kebutuhan[it["barangId"]] = kebutuhan.get(it["barangId"], 0) + it["qty"]
    if not errors and j.pola in ("penjualan", "kerugian"):
        for it in items:
            tersedia = saldo[it["barangId"]].qty
            if kebutuhan[it["barangId"]] > tersedia:
                errors[f"item_{it['urut'] - 1}_qty"] = (
                    f"Stok {it['nama']} tidak cukup (tersedia {format_qty(tersedia)} {it['satuan']}, "
                    f"diminta {format_qty(kebutuhan[it['barangId']])} {it['satuan']})"
                )
    if errors:
        raise ProsesTransaksiError(errors)

    # Mutasi kartu (urut sesuai baris barang).
    arah = "masuk" if j.pola == "pembelian_barang" else "keluar"
    sumber = {"penjualan": "penjualan", "pembelian_barang": "pembelian", "kerugian": "kerugian"}.get(j.pola)
    try:
        for it in items:
            bid = it["barangId"]
            mutasi, saldo[bid] = terapkan_mutasi(
                saldo[bid], arah, it["qty"], it["subtotal"] if arah == "masuk" else None,
                nama=it["nama"], satuan=it["satuan"],
            )
            urut_kartu[bid] += 1
            tambah_kartu(conn, bid, urut_kartu[bid], tanggal, mutasi, sumber, trx["keterangan"], transaksi_id=transaksi_id)
            if arah == "keluar":
                nilai_pokok_total += mutasi.nilai
                conn.execute("UPDATE TransaksiItem SET nilaiPokok = ? WHERE id = ?", (mutasi.nilai, it["id"]))
    except PersediaanError as error:
        raise ProsesTransaksiError({"items": str(error)}) from error

    total = nilai_pokok_total if j.pola == "kerugian" else trx["nominal"]
    try:
        akun_valid = {r["kode"] for r in conn.execute("SELECT kode FROM Account")}
        baris = periksa_jurnal(susun_jurnal(trx["jenis"], detail, total, nilai_pokok_total), akun_valid)
    except JurnalError as error:
        raise ProsesTransaksiError({"umum": str(error)}) from error

    nomor = ambil_nomor(conn, "JU", tanggal)
    jurnal_id = buat_jurnal(conn, trx["periodId"], nomor, tanggal, trx["keterangan"], "UMUM", baris, transaksi_id)
    posting_jurnal(conn, jurnal_id)
    conn.execute(
        "UPDATE Transaksi SET status = 'terjurnal', nominal = ?, hpp = ? WHERE id = ?",
        (total, nilai_pokok_total if arah == "keluar" else None, transaksi_id),
    )
    return HasilProses(transaksi_id, jurnal_id, trx["noBukti"], nomor)
