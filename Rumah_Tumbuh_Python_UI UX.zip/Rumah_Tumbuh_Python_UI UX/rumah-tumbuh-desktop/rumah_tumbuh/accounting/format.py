"""Pembacaan dan format angka. Uang = rupiah bulat; jumlah barang = seperseribu satuan (int)."""

import re

QTY_SKALA = 1000
MAKS_UANG = 999_999_999_999


class FormatError(ValueError):
    """Isian angka tidak dapat dibaca."""


def parse_rupiah(text: str, *, boleh_nol: bool = False) -> int:
    """Baca nominal rupiah bulat, mis. '1.250.000' atau 'Rp 1250000'."""
    bersih = re.sub(r"(?i)rp", "", str(text or "")).replace(" ", "").strip()
    if not bersih:
        raise FormatError("Isi nominal.")
    if "," in bersih:
        raise FormatError("Gunakan angka bulat tanpa koma.")
    bersih = bersih.replace(".", "")
    if not bersih.isdigit():
        raise FormatError("Nominal harus berupa angka.")
    nilai = int(bersih)
    if nilai == 0 and not boleh_nol:
        raise FormatError("Nominal harus lebih dari 0.")
    if nilai > MAKS_UANG:
        raise FormatError("Nominal terlalu besar (maksimal Rp999.999.999.999).")
    return nilai


def parse_qty(text: str) -> int:
    """Baca jumlah barang (maksimal 3 desimal, koma atau titik) menjadi seperseribu satuan."""
    bersih = str(text or "").strip().replace(" ", "")
    if not bersih:
        raise FormatError("Isi jumlah.")
    if "," in bersih:
        bersih = bersih.replace(".", "").replace(",", ".")
    if not re.fullmatch(r"\d+(\.\d{1,3})?", bersih):
        raise FormatError("Jumlah harus berupa angka (maksimal 3 angka di belakang koma).")
    bagian, _, desimal = bersih.partition(".")
    nilai = int(bagian) * QTY_SKALA + int(desimal.ljust(3, "0") or 0)
    if nilai <= 0:
        raise FormatError("Jumlah harus lebih dari 0.")
    return nilai


def format_qty(milli: int) -> str:
    """Tampilkan jumlah dengan koma desimal, mis. 16 atau 2,5."""
    tanda = "-" if milli < 0 else ""
    milli = abs(milli)
    bulat, sisa = divmod(milli, QTY_SKALA)
    ribuan = f"{bulat:,}".replace(",", ".")
    if sisa == 0:
        return tanda + ribuan
    return tanda + ribuan + "," + f"{sisa:03d}".rstrip("0")


def format_rupiah(value: int) -> str:
    """Format Rp 1.250.000 (negatif: -Rp 1.250.000)."""
    teks = f"{abs(int(value)):,}".replace(",", ".")
    return ("-Rp " if value < 0 else "Rp ") + teks


def bagi_bulat_setengah_naik(pembilang: int, penyebut: int) -> int:
    """Pembagian bilangan bulat non-negatif dibulatkan ROUND_HALF_UP."""
    return (2 * pembilang + penyebut) // (2 * penyebut)
