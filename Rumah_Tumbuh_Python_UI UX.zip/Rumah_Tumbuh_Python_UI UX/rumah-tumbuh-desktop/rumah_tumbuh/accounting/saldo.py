"""Perhitungan saldo akun dari buku besar (Neraca Saldo, saldo kas, ringkasan)."""

from ..db import transaction


def daftar_periode(conn) -> list[dict]:
    """Semua periode, terlama dulu."""
    return [dict(r) for r in conn.execute(
        "SELECT id, nama, tanggalMulai, tanggalAkhir, status FROM Period ORDER BY tanggalMulai ASC")]


def neraca_saldo(conn, period_id: str, sesudah_penutup: bool = False) -> dict:
    """Neraca saldo akumulatif sampai akhir periode.

    Memuat mutasi periode itu dan periode sebelumnya. Jurnal penutup periode itu hanya ikut bila
    `sesudah_penutup` True. Saldo ditempatkan pada kolom sesuai tandanya (saldo normal).
    """
    periode = conn.execute("SELECT tanggalMulai FROM Period WHERE id = ?", (period_id,)).fetchone()
    if periode is None:
        return {"baris": [], "total_debit": 0, "total_kredit": 0}
    sql = (
        "SELECT a.kode, a.nama, a.posSaldo, a.posLaporan, SUM(b.debit) AS d, SUM(b.kredit) AS k "
        "FROM BukuBesar b JOIN Account a ON a.kode = b.akunKode "
        "JOIN JurnalLine l ON l.id = b.jurnalLineId JOIN JurnalUmum j ON j.id = l.jurnalId "
        "JOIN Period p ON p.id = b.periodId WHERE p.tanggalMulai <= ? "
    )
    params: list = [periode["tanggalMulai"]]
    if not sesudah_penutup:
        sql += "AND NOT (j.jenis = 'PENUTUP' AND b.periodId = ?) "
        params.append(period_id)
    sql += "GROUP BY a.kode ORDER BY a.kode"
    baris, total_d, total_k = [], 0, 0
    for r in conn.execute(sql, params):
        net = (r["d"] - r["k"]) if r["posSaldo"] == "DB" else (r["k"] - r["d"])
        if net == 0 and r["d"] == 0 and r["k"] == 0:
            continue
        ke_debit = (r["posSaldo"] == "DB") == (net >= 0)
        jumlah = abs(net)
        deb, kre = (jumlah, 0) if ke_debit else (0, jumlah)
        total_d += deb
        total_k += kre
        baris.append({"kode": r["kode"], "nama": r["nama"], "posSaldo": r["posSaldo"],
                      "posLaporan": r["posLaporan"], "debit": deb, "kredit": kre, "saldo": net})
    return {"baris": baris, "total_debit": total_d, "total_kredit": total_k}


def saldo_akun(conn, kode: str) -> int:
    """Saldo akun menurut sisi normalnya (kumulatif seluruh periode)."""
    r = conn.execute(
        "SELECT a.posSaldo, COALESCE(SUM(b.debit),0) d, COALESCE(SUM(b.kredit),0) k FROM Account a "
        "LEFT JOIN BukuBesar b ON b.akunKode = a.kode WHERE a.kode = ?", (kode,)).fetchone()
    if r is None:
        return 0
    return (r["d"] - r["k"]) if r["posSaldo"] == "DB" else (r["k"] - r["d"])


def ringkasan_dashboard(conn) -> dict | None:
    """Data dashboard dari database (satu pembacaan konsisten)."""
    with transaction(conn, immediate=False):
        periode = conn.execute(
            "SELECT id, nama, tanggalMulai, tanggalAkhir FROM Period WHERE status = 'AKTIF' "
            "ORDER BY tanggalMulai DESC LIMIT 1").fetchone()
        if periode is None:
            return None
        ns = neraca_saldo(conn, periode["id"])
        terakhir = conn.execute(
            "SELECT id, tanggal, keterangan, nominal, noBukti, jenis, status FROM Transaksi "
            "WHERE periodId = ? ORDER BY tanggal DESC, createdAt DESC, rowid DESC LIMIT 5",
            (periode["id"],)).fetchall()
        jumlah = conn.execute(
            "SELECT COUNT(*) FROM Transaksi WHERE periodId = ?", (periode["id"],)).fetchone()[0]
    return {"periode": dict(periode), "neraca": ns, "terakhir": [dict(r) for r in terakhir], "jumlah": jumlah}
