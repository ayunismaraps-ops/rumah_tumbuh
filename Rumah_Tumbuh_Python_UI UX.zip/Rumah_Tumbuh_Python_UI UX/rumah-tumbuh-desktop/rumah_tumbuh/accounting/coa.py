"""Daftar akun (COA) Rumah Tumbuh. Sumber: coa.csv (CHART OF ACCOUNTS for 'Rumah Tumbuh').

Akun 3130 Ikhtisar Laba Rugi kosong pada berkas sumber; dipakai khusus jurnal penutup,
sehingga disimpan dengan saldo normal KR dan laporan NRC. Hanya jurnal penutup yang boleh memakainya.
"""

COA = [
    {"kode": "1110", "nama": "Kas", "posSaldo": "DB", "posLaporan": "NRC"},
    {"kode": "1120", "nama": "Bank", "posSaldo": "DB", "posLaporan": "NRC"},
    {"kode": "1130", "nama": "Piutang Usaha", "posSaldo": "DB", "posLaporan": "NRC"},
    {"kode": "1140", "nama": "Persediaan Barang Dagang", "posSaldo": "DB", "posLaporan": "NRC"},
    {"kode": "1150", "nama": "Perlengkapan Kebun", "posSaldo": "DB", "posLaporan": "NRC"},
    {"kode": "1210", "nama": "Tanah Kebun", "posSaldo": "DB", "posLaporan": "NRC"},
    {"kode": "1220", "nama": "Gudang", "posSaldo": "DB", "posLaporan": "NRC"},
    {"kode": "1221", "nama": "Akm. Penyusutan Gudang", "posSaldo": "KR", "posLaporan": "NRC"},
    {"kode": "1230", "nama": "Gubuk Kebun", "posSaldo": "DB", "posLaporan": "NRC"},
    {"kode": "1231", "nama": "Akm. Penyusutan Gubuk Kebun", "posSaldo": "KR", "posLaporan": "NRC"},
    {"kode": "1260", "nama": "Peralatan Kebun", "posSaldo": "DB", "posLaporan": "NRC"},
    {"kode": "1261", "nama": "Akm. Penyusutan Peralatan", "posSaldo": "KR", "posLaporan": "NRC"},
    {"kode": "2110", "nama": "Utang Usaha", "posSaldo": "KR", "posLaporan": "NRC"},
    {"kode": "2120", "nama": "Utang Gaji", "posSaldo": "KR", "posLaporan": "NRC"},
    {"kode": "2210", "nama": "Utang Bank", "posSaldo": "KR", "posLaporan": "NRC"},
    {"kode": "3110", "nama": "Modal", "posSaldo": "KR", "posLaporan": "NRC"},
    {"kode": "3120", "nama": "Prive", "posSaldo": "DB", "posLaporan": "NRC"},
    {"kode": "3130", "nama": "Ikhtisar Laba Rugi", "posSaldo": "KR", "posLaporan": "NRC"},
    {"kode": "4110", "nama": "Penjualan", "posSaldo": "KR", "posLaporan": "LR"},
    {"kode": "4120", "nama": "Pendapatan Lain-Lain", "posSaldo": "KR", "posLaporan": "LR"},
    {"kode": "5110", "nama": "Harga Pokok Penjualan", "posSaldo": "DB", "posLaporan": "LR"},
    {"kode": "5120", "nama": "Kerugian Persediaan/Gagal Panen", "posSaldo": "DB", "posLaporan": "LR"},
    {"kode": "6110", "nama": "Beban Gaji Karyawan", "posSaldo": "DB", "posLaporan": "LR"},
    {"kode": "6120", "nama": "Beban Perlengkapan Kebun", "posSaldo": "DB", "posLaporan": "LR"},
    {"kode": "6130", "nama": "Beban Listrik dan Air", "posSaldo": "DB", "posLaporan": "LR"},
    {"kode": "6140", "nama": "Beban Penyusutan", "posSaldo": "DB", "posLaporan": "LR"},
    {"kode": "6150", "nama": "Beban Transportasi", "posSaldo": "DB", "posLaporan": "LR"},
    {"kode": "6160", "nama": "Beban Lain-Lain", "posSaldo": "DB", "posLaporan": "LR"},
]
