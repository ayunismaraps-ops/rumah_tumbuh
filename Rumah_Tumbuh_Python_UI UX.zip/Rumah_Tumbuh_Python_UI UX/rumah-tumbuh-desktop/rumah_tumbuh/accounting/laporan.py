"""Laporan keuangan dari neraca saldo sebelum penutup: Laba Rugi, Neraca, Arus Kas."""

from .saldo import neraca_saldo

AKUN_KAS_BANK = ("1110", "1120")
AKUN_INVESTASI = ("1210", "1220", "1230", "1260")
AKUN_PENDANAAN = ("2210", "3110", "3120")


def _baris(ns: dict, awalan: tuple[str, ...]) -> list[dict]:
    return [r for r in ns["baris"] if r["kode"].startswith(awalan)]


def laba_rugi(conn, period_id: str) -> dict:
    """Laporan laba rugi satu periode."""
    ns = neraca_saldo(conn, period_id)
    pendapatan = _baris(ns, ("4110",))
    lain = _baris(ns, ("4120",))
    hpp = _baris(ns, ("5110",))
    kerugian = _baris(ns, ("5120",))
    beban = _baris(ns, ("6",))
    jumlah = lambda rows: sum(r["saldo"] for r in rows)  # noqa: E731
    laba_kotor = jumlah(pendapatan) - jumlah(hpp)
    beban_usaha = jumlah(kerugian) + jumlah(beban)
    laba_usaha = laba_kotor - beban_usaha
    laba_bersih = laba_usaha + jumlah(lain)
    return {
        "pendapatan": pendapatan, "total_pendapatan": jumlah(pendapatan),
        "hpp": hpp, "total_hpp": jumlah(hpp), "laba_kotor": laba_kotor,
        "kerugian": kerugian, "beban": beban, "total_beban": beban_usaha,
        "laba_usaha": laba_usaha, "lain": lain, "total_lain": jumlah(lain), "laba_bersih": laba_bersih,
    }


def neraca(conn, period_id: str) -> dict:
    """Laporan posisi keuangan. Akun kontra aset (saldo kredit) ditampilkan negatif."""
    ns = neraca_saldo(conn, period_id)
    lr = laba_rugi(conn, period_id)
    aset = [{**r, "tampil": r["saldo"] if r["posSaldo"] == "DB" else -r["saldo"]} for r in _baris(ns, ("1",))]
    liabilitas = [{**r, "tampil": r["saldo"]} for r in _baris(ns, ("2",))]
    modal = [{**r, "tampil": r["saldo"]} for r in _baris(ns, ("3110",))]
    prive = [{**r, "tampil": -r["saldo"]} for r in _baris(ns, ("3120",))]
    total_aset = sum(r["tampil"] for r in aset)
    total_liab = sum(r["tampil"] for r in liabilitas)
    total_ekuitas = sum(r["tampil"] for r in modal + prive) + lr["laba_bersih"]
    return {
        "aset": aset, "total_aset": total_aset, "liabilitas": liabilitas, "total_liabilitas": total_liab,
        "modal": modal, "prive": prive, "laba_berjalan": lr["laba_bersih"], "total_ekuitas": total_ekuitas,
        "total_liab_ekuitas": total_liab + total_ekuitas, "seimbang": total_aset == total_liab + total_ekuitas,
    }


def _golongan(akun_lawan: list[str]) -> str:
    if any(a.startswith(AKUN_INVESTASI) or a in ("1221", "1231", "1261") for a in akun_lawan):
        return "investasi"
    if any(a in AKUN_PENDANAAN for a in akun_lawan):
        return "pendanaan"
    return "operasi"


def arus_kas(conn, period_id: str) -> dict:
    """Arus kas metode langsung dari jurnal yang menyentuh Kas/Bank. Pindah dana Kas-Bank tidak dihitung."""
    periode = conn.execute("SELECT tanggalMulai, tanggalAkhir FROM Period WHERE id = ?", (period_id,)).fetchone()
    awal = conn.execute(
        "SELECT COALESCE(SUM(b.debit) - SUM(b.kredit), 0) FROM BukuBesar b JOIN Period p ON p.id = b.periodId "
        "WHERE b.akunKode IN ('1110','1120') AND p.tanggalMulai < ?", (periode["tanggalMulai"],)).fetchone()[0]
    jurnal = conn.execute(
        "SELECT DISTINCT j.id, j.keterangan FROM JurnalUmum j JOIN JurnalLine l ON l.jurnalId = j.id "
        "JOIN Period p ON p.id = j.periodId WHERE p.id = ? AND l.akunKode IN ('1110','1120') "
        "AND j.jenis != 'PENUTUP' ORDER BY j.tanggal, j.rowid", (period_id,)).fetchall()
    hasil = {"operasi": [], "investasi": [], "pendanaan": []}
    for j in jurnal:
        lines = conn.execute(
            "SELECT l.akunKode, l.debit, l.kredit, a.nama FROM JurnalLine l JOIN Account a ON a.kode = l.akunKode "
            "WHERE l.jurnalId = ? ORDER BY l.rowid", (j["id"],)).fetchall()
        efek = sum(r["debit"] - r["kredit"] for r in lines if r["akunKode"] in AKUN_KAS_BANK)
        lawan = [r for r in lines if r["akunKode"] not in AKUN_KAS_BANK]
        if efek == 0 or not lawan:
            continue
        utama = max(lawan, key=lambda r: r["debit"] + r["kredit"])
        hasil[_golongan([r["akunKode"] for r in lawan])].append(
            {"keterangan": j["keterangan"], "akun": f"{utama['akunKode']} {utama['nama']}", "jumlah": efek})
    total = {k: sum(r["jumlah"] for r in v) for k, v in hasil.items()}
    kenaikan = sum(total.values())
    akhir = awal + kenaikan
    sebenarnya = conn.execute(
        "SELECT COALESCE(SUM(b.debit) - SUM(b.kredit), 0) FROM BukuBesar b JOIN Period p ON p.id = b.periodId "
        "WHERE b.akunKode IN ('1110','1120') AND p.tanggalMulai <= ?", (periode["tanggalMulai"],)).fetchone()[0]
    return {**{f"baris_{k}": v for k, v in hasil.items()}, **{f"total_{k}": v for k, v in total.items()},
            "kas_awal": awal, "kenaikan": kenaikan, "kas_akhir": akhir, "cocok": akhir == sebenarnya}
