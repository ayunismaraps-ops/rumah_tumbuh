"""Penomoran berurutan per awalan dan bulan. Wajib dipanggil di dalam transaksi database."""

from datetime import date


def ambil_nomor(conn, prefix: str, tanggal: date) -> str:
    """Ambil nomor berikutnya, mis. JU-202611-0001. Ikut dibatalkan bila transaksi di-rollback."""
    bulan = tanggal.strftime("%Y%m")
    row = conn.execute(
        "SELECT terakhir FROM Penomoran WHERE prefix = ? AND bulan = ?", (prefix, bulan)
    ).fetchone()
    if row is None:
        urut = 1
        conn.execute("INSERT INTO Penomoran (prefix, bulan, terakhir) VALUES (?, ?, 1)", (prefix, bulan))
    else:
        urut = row["terakhir"] + 1
        conn.execute(
            "UPDATE Penomoran SET terakhir = ? WHERE prefix = ? AND bulan = ?", (urut, prefix, bulan)
        )
    return f"{prefix}-{bulan}-{urut:04d}"
