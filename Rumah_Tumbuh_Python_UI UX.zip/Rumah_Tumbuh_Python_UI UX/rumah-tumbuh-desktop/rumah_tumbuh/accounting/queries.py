"""Query baca-saja untuk halaman Jurnal Umum, Kartu Persediaan, Buku Besar, dan hasil transaksi."""

from .. import tanggal as tgl
from .format import bagi_bulat_setengah_naik

HALAMAN = 20


def _rentang(dari, sampai, kolom: str) -> tuple[str, list]:
    sql, params = "", []
    if dari:
        sql += f" AND {kolom} >= ?"
        params.append(tgl.date_to_db(dari))
    if sampai:
        sql += f" AND {kolom} <= ?"
        params.append(tgl.date_to_db(sampai))
    return sql, params


def jurnal_umum(conn, dari=None, sampai=None, jenis: str = "", halaman: int = 1, fokus: str = "") -> dict:
    """Jurnal kronologis dengan paginasi 20 per halaman. `fokus` = nomor jurnal yang ingin ditampilkan."""
    where, params = " WHERE 1=1", []
    rentang, p = _rentang(dari, sampai, "j.tanggal")
    where += rentang
    params += p
    if jenis in ("UMUM", "PENYESUAIAN", "PENUTUP"):
        where += " AND j.jenis = ?"
        params.append(jenis)
    if fokus:
        where += " AND j.nomor = ?"
        params.append(fokus)
    total = conn.execute(f"SELECT COUNT(*) FROM JurnalUmum j{where}", params).fetchone()[0]
    halaman = max(1, halaman)
    heads = conn.execute(
        "SELECT j.id, j.nomor, j.tanggal, j.keterangan, j.jenis, t.noBukti, t.pihak FROM JurnalUmum j "
        f"LEFT JOIN Transaksi t ON t.id = j.transaksiId{where} ORDER BY j.tanggal ASC, j.rowid ASC LIMIT ? OFFSET ?",
        params + [HALAMAN, (halaman - 1) * HALAMAN]).fetchall()
    jurnal = []
    for h in heads:
        baris = conn.execute(
            "SELECT l.akunKode, a.nama, l.debit, l.kredit FROM JurnalLine l JOIN Account a ON a.kode = l.akunKode "
            "WHERE l.jurnalId = ? ORDER BY l.rowid", (h["id"],)).fetchall()
        d = dict(h)
        d["tanggal"] = tgl.db_to_date(h["tanggal"])
        d["baris"] = [dict(b) for b in baris]
        d["total_debit"] = sum(b["debit"] for b in baris)
        d["total_kredit"] = sum(b["kredit"] for b in baris)
        jurnal.append(d)
    return {"jurnal": jurnal, "total": total, "halaman": halaman,
            "jumlah_halaman": max(1, -(-total // HALAMAN))}


def akun_bergerak(conn) -> list[dict]:
    """Akun yang punya pergerakan di buku besar."""
    return [dict(r) for r in conn.execute(
        "SELECT a.kode, a.nama, a.posSaldo FROM Account a WHERE EXISTS "
        "(SELECT 1 FROM BukuBesar b WHERE b.akunKode = a.kode) ORDER BY a.kode")]


def buku_besar_akun(conn, kode: str, dari=None, sampai=None) -> dict:
    """Buku besar satu akun dengan saldo berjalan dari database."""
    akun = conn.execute("SELECT kode, nama, posSaldo FROM Account WHERE kode = ?", (kode,)).fetchone()
    if akun is None:
        return {"akun": None, "baris": [], "saldo_akhir": 0}
    rentang, params = _rentang(dari, sampai, "b.tanggal")
    rows = conn.execute(
        "SELECT b.tanggal, j.nomor, j.keterangan, b.debit, b.kredit, b.saldoBerjalan FROM BukuBesar b "
        "JOIN JurnalLine l ON l.id = b.jurnalLineId JOIN JurnalUmum j ON j.id = l.jurnalId "
        f"WHERE b.akunKode = ?{rentang} ORDER BY b.tanggal, j.rowid, l.rowid", [kode] + params).fetchall()
    baris = [{**dict(r), "tanggal": tgl.db_to_date(r["tanggal"])} for r in rows]
    saldo_akhir = conn.execute(
        "SELECT saldoBerjalan FROM BukuBesar b JOIN JurnalLine l ON l.id = b.jurnalLineId "
        "JOIN JurnalUmum j ON j.id = l.jurnalId WHERE b.akunKode = ? ORDER BY b.tanggal DESC, j.rowid DESC, l.rowid DESC LIMIT 1",
        (kode,)).fetchone()
    return {"akun": dict(akun), "baris": baris, "saldo_akhir": saldo_akhir[0] if saldo_akhir else 0,
            "total_debit": sum(b["debit"] for b in baris), "total_kredit": sum(b["kredit"] for b in baris)}


def ringkasan_buku_besar(conn) -> list[dict]:
    """Saldo akhir tiap akun menurut sisi normalnya."""
    hasil = []
    for r in conn.execute(
            "SELECT a.kode, a.nama, a.posSaldo, SUM(b.debit) d, SUM(b.kredit) k FROM Account a "
            "JOIN BukuBesar b ON b.akunKode = a.kode GROUP BY a.kode ORDER BY a.kode"):
        saldo = (r["d"] - r["k"]) if r["posSaldo"] == "DB" else (r["k"] - r["d"])
        hasil.append({"kode": r["kode"], "nama": r["nama"], "posSaldo": r["posSaldo"], "debit": r["d"],
                      "kredit": r["k"], "saldo": saldo})
    return hasil


def kartu_barang(conn, barang_id: str, dari=None, sampai=None) -> list[dict]:
    """Baris kartu persediaan satu barang (urut kronologis) lengkap dengan harga satuan."""
    rentang, params = _rentang(dari, sampai, "k.tanggal")
    rows = conn.execute(
        "SELECT k.*, t.noBukti, j.nomor AS nomorJurnal FROM KartuPersediaan k "
        "LEFT JOIN Transaksi t ON t.id = k.transaksiId LEFT JOIN JurnalUmum j ON j.id = k.jurnalId "
        f"WHERE k.barangId = ?{rentang} ORDER BY k.urut", [barang_id] + params).fetchall()
    hasil = []
    for r in rows:
        d = dict(r)
        d["tanggal"] = tgl.db_to_date(r["tanggal"])
        d["harga"] = bagi_bulat_setengah_naik(r["nilai"] * 1000, r["qty"])
        d["harga_saldo"] = bagi_bulat_setengah_naik(r["saldoNilai"] * 1000, r["saldoQty"]) if r["saldoQty"] else 0
        d["referensi"] = r["noBukti"] or r["nomorJurnal"] or "-"
        hasil.append(d)
    return hasil


def detail_transaksi(conn, transaksi_id: str) -> dict | None:
    """Ringkasan satu transaksi untuk layar sukses dan invoice: jurnal, barang, stok sekarang."""
    t = conn.execute("SELECT * FROM Transaksi WHERE id = ?", (transaksi_id,)).fetchone()
    if t is None:
        return None
    d = dict(t)
    d["tanggal"] = tgl.db_to_date(t["tanggal"])
    j = conn.execute("SELECT id, nomor FROM JurnalUmum WHERE transaksiId = ?", (transaksi_id,)).fetchone()
    d["jurnal_nomor"] = j["nomor"] if j else None
    d["baris"] = [dict(b) for b in conn.execute(
        "SELECT l.akunKode, a.nama, l.debit, l.kredit FROM JurnalLine l JOIN Account a ON a.kode = l.akunKode "
        "WHERE l.jurnalId = ? ORDER BY l.rowid", (j["id"],))] if j else []
    d["items"] = [dict(i) for i in conn.execute(
        "SELECT i.*, b.nama, b.satuan, COALESCE((SELECT saldoQty FROM KartuPersediaan WHERE barangId = b.id "
        "ORDER BY urut DESC LIMIT 1), 0) AS stok_sekarang FROM TransaksiItem i JOIN Barang b ON b.id = i.barangId "
        "WHERE i.transaksiId = ? ORDER BY i.urut", (transaksi_id,))]
    return d


def daftar_penjualan(conn, halaman: int = 1) -> dict:
    """Transaksi penjualan untuk halaman Invoice."""
    total = conn.execute("SELECT COUNT(*) FROM Transaksi WHERE jenis = 'penjualan'").fetchone()[0]
    rows = conn.execute(
        "SELECT id, noBukti, tanggal, pihak, nominal, metode FROM Transaksi WHERE jenis = 'penjualan' "
        "ORDER BY tanggal DESC, rowid DESC LIMIT ? OFFSET ?", (HALAMAN, (max(1, halaman) - 1) * HALAMAN)).fetchall()
    return {"baris": [{**dict(r), "tanggal": tgl.db_to_date(r["tanggal"])} for r in rows], "total": total,
            "halaman": max(1, halaman), "jumlah_halaman": max(1, -(-total // HALAMAN))}


def daftar_penyesuaian(conn, period_id: str) -> list[dict]:
    """Jurnal penyesuaian pada satu periode."""
    hasil = []
    for h in conn.execute("SELECT id, nomor, tanggal, keterangan FROM JurnalUmum WHERE periodId = ? "
                          "AND jenis = 'PENYESUAIAN' ORDER BY tanggal, rowid", (period_id,)):
        d = dict(h)
        d["tanggal"] = tgl.db_to_date(h["tanggal"])
        d["baris"] = [dict(b) for b in conn.execute(
            "SELECT l.akunKode, a.nama, l.debit, l.kredit FROM JurnalLine l JOIN Account a ON a.kode = l.akunKode "
            "WHERE l.jurnalId = ? ORDER BY l.rowid", (h["id"],))]
        hasil.append(d)
    return hasil
