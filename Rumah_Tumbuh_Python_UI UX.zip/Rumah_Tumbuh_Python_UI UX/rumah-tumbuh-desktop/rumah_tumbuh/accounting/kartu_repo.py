"""Akses data kartu persediaan. Kartu hanya ditambah, tidak pernah diubah atau dihapus."""

from datetime import date

from ..db import new_id
from ..tanggal import date_to_db, db_to_date
from .persediaan_engine import MutasiKartu, SaldoBarang


def saldo_terakhir(conn, barang_id: str) -> tuple[SaldoBarang, date | None, int]:
    """Saldo terakhir barang: (saldo, tanggal entri terakhir, nomor urut terakhir)."""
    row = conn.execute(
        "SELECT urut, tanggal, saldoQty, saldoNilai FROM KartuPersediaan "
        "WHERE barangId = ? ORDER BY urut DESC LIMIT 1",
        (barang_id,),
    ).fetchone()
    if row is None:
        return SaldoBarang(), None, 0
    return SaldoBarang(row["saldoQty"], row["saldoNilai"]), db_to_date(row["tanggal"]), row["urut"]


def tambah_kartu(
    conn,
    barang_id: str,
    urut: int,
    tanggal: date,
    mutasi: MutasiKartu,
    sumber: str,
    keterangan: str,
    transaksi_id: str | None = None,
    jurnal_id: str | None = None,
) -> str:
    """Simpan satu baris kartu. Mengembalikan id baris."""
    kartu_id = new_id()
    conn.execute(
        "INSERT INTO KartuPersediaan (id, barangId, urut, tanggal, transaksiId, jurnalId, arah, sumber, "
        "qty, nilai, saldoQty, saldoNilai, keterangan) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (kartu_id, barang_id, urut, date_to_db(tanggal), transaksi_id, jurnal_id, mutasi.arah, sumber,
         mutasi.qty, mutasi.nilai, mutasi.saldo_qty, mutasi.saldo_nilai, keterangan),
    )
    return kartu_id


def rekonsiliasi(conn) -> dict[str, dict]:
    """Bandingkan total nilai kartu dengan saldo akun kontrol (1140 dagang, 1150 perlengkapan)."""
    hasil: dict[str, dict] = {}
    for kategori, akun in (("dagang", "1140"), ("perlengkapan", "1150")):
        kartu = conn.execute(
            "SELECT COALESCE(SUM(k.saldoNilai), 0) FROM Barang b JOIN KartuPersediaan k ON k.barangId = b.id "
            "AND k.urut = (SELECT MAX(urut) FROM KartuPersediaan WHERE barangId = b.id) "
            "WHERE b.kategori = ?",
            (kategori,),
        ).fetchone()[0]
        buku = conn.execute(
            "SELECT COALESCE(SUM(debit), 0) - COALESCE(SUM(kredit), 0) FROM BukuBesar WHERE akunKode = ?",
            (akun,),
        ).fetchone()[0]
        hasil[kategori] = {"akun": akun, "kartu": kartu, "buku_besar": buku, "selisih": kartu - buku}
    return hasil
