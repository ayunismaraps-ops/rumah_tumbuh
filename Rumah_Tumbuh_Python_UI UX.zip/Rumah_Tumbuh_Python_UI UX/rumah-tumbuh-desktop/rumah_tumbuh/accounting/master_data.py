"""Master barang. Stok selalu dibaca dari kartu persediaan; barang tidak pernah dihapus."""

import sqlite3

from ..db import new_id, transaction
from .format import FormatError, bagi_bulat_setengah_naik, parse_rupiah
from .transaksi_config import KATEGORI_LABEL


class BarangError(Exception):
    """Isian barang tidak valid. `errors` berisi pesan per field."""

    def __init__(self, errors: dict[str, str]):
        super().__init__("; ".join(errors.values()))
        self.errors = errors


def _baca(form: dict, kategori_tetap: str | None = None, satuan_tetap: str | None = None) -> dict:
    errors: dict[str, str] = {}
    nama = " ".join((form.get("nama") or "").split())
    if len(nama) < 2:
        errors["nama"] = "Nama barang minimal 2 karakter."
    elif len(nama) > 80:
        errors["nama"] = "Nama barang maksimal 80 karakter."
    kategori = kategori_tetap or (form.get("kategori") or "").strip()
    if kategori not in KATEGORI_LABEL:
        errors["kategori"] = "Pilih kategori barang."
    satuan = satuan_tetap or " ".join((form.get("satuan") or "").split())
    if not satuan:
        errors["satuan"] = "Isi satuan (contoh: kg, karung, buah)."
    elif len(satuan) > 20:
        errors["satuan"] = "Satuan maksimal 20 karakter."
    harga = {}
    for field in ("harga_beli", "harga_jual"):
        teks = (form.get(field) or "").strip()
        harga[field] = None
        if teks:
            try:
                harga[field] = parse_rupiah(teks)
            except FormatError as e:
                errors[field] = str(e)
    if kategori == "perlengkapan" and harga["harga_jual"] is not None:
        errors["harga_jual"] = "Harga jual hanya untuk barang dagang."
    if errors:
        raise BarangError(errors)
    return {"nama": nama, "kategori": kategori, "satuan": satuan, **harga}


def tambah_barang(conn, form: dict) -> str:
    """Tambah barang baru. Nama unik per kategori (huruf besar/kecil dianggap sama)."""
    data = _baca(form)
    barang_id = new_id()
    try:
        with transaction(conn):
            conn.execute(
                "INSERT INTO Barang (id, nama, namaKunci, kategori, satuan, hargaBeli, hargaJual) VALUES (?,?,?,?,?,?,?)",
                (barang_id, data["nama"], data["nama"].lower(), data["kategori"], data["satuan"],
                 data["harga_beli"], data["harga_jual"]),
            )
    except sqlite3.IntegrityError as error:
        raise BarangError({"nama": f"{data['nama']} sudah ada pada kategori {KATEGORI_LABEL[data['kategori']].lower()}."}) from error
    return barang_id


def punya_riwayat(conn, barang_id: str) -> bool:
    """Apakah barang sudah punya riwayat kartu."""
    return conn.execute("SELECT 1 FROM KartuPersediaan WHERE barangId = ? LIMIT 1", (barang_id,)).fetchone() is not None


def ubah_barang(conn, barang_id: str, form: dict) -> None:
    """Ubah nama, harga default, dan status aktif. Kategori/satuan terkunci bila sudah ada riwayat."""
    with transaction(conn):
        lama = conn.execute("SELECT * FROM Barang WHERE id = ?", (barang_id,)).fetchone()
        if lama is None:
            raise BarangError({"umum": "Barang tidak ditemukan."})
        terkunci = punya_riwayat(conn, barang_id)
        if terkunci:
            baru_kategori = (form.get("kategori") or lama["kategori"]).strip()
            baru_satuan = " ".join((form.get("satuan") or lama["satuan"]).split())
            if baru_kategori != lama["kategori"] or baru_satuan != lama["satuan"]:
                raise BarangError({"kategori": "Kategori dan satuan tidak bisa diubah karena barang sudah punya riwayat stok."})
        data = _baca(form, lama["kategori"] if terkunci else None, lama["satuan"] if terkunci else None)
        aktif = 1 if form.get("aktif") in ("1", "on", "true", True) else 0
        try:
            conn.execute(
                "UPDATE Barang SET nama=?, namaKunci=?, kategori=?, satuan=?, hargaBeli=?, hargaJual=?, aktif=? WHERE id=?",
                (data["nama"], data["nama"].lower(), data["kategori"], data["satuan"], data["harga_beli"],
                 data["harga_jual"], aktif, barang_id),
            )
        except sqlite3.IntegrityError as error:
            raise BarangError({"nama": f"{data['nama']} sudah ada pada kategori {KATEGORI_LABEL[data['kategori']].lower()}."}) from error


def daftar_barang(conn, cari: str = "", kategori: str = "", hanya_aktif: bool = False) -> list[dict]:
    """Daftar barang beserta stok, harga pokok rata-rata (per satuan), dan nilai persediaan."""
    sql = (
        "SELECT b.*, COALESCE(k.saldoQty, 0) AS stok, COALESCE(k.saldoNilai, 0) AS nilai, "
        "EXISTS(SELECT 1 FROM KartuPersediaan WHERE barangId = b.id) AS ada_riwayat "
        "FROM Barang b LEFT JOIN KartuPersediaan k ON k.barangId = b.id "
        "AND k.urut = (SELECT MAX(urut) FROM KartuPersediaan WHERE barangId = b.id) WHERE 1=1 "
    )
    params: list = []
    if cari.strip():
        sql += "AND b.namaKunci LIKE ? "
        params.append(f"%{cari.strip().lower()}%")
    if kategori in KATEGORI_LABEL:
        sql += "AND b.kategori = ? "
        params.append(kategori)
    if hanya_aktif:
        sql += "AND b.aktif = 1 "
    sql += "ORDER BY b.kategori, b.namaKunci"
    hasil = []
    for r in conn.execute(sql, params):
        d = dict(r)
        d["rata_rata"] = bagi_bulat_setengah_naik(d["nilai"] * 1000, d["stok"]) if d["stok"] else 0
        hasil.append(d)
    return hasil


def barang_pilihan(conn, kategori: str) -> list[dict]:
    """Barang aktif untuk dipilih di form transaksi, lengkap dengan stok saat ini."""
    return daftar_barang(conn, kategori=kategori, hanya_aktif=True)
