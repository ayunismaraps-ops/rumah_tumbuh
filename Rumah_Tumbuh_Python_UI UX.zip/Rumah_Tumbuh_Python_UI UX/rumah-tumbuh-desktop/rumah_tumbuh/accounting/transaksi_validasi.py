"""Validasi isian transaksi (murni, tanpa database dan tanpa Flask).

Pemeriksaan yang butuh database (stok, tanggal kartu, periode) ada di proses_transaksi.py.
"""

from dataclasses import dataclass, field
from datetime import date

from ..tanggal import parse_tanggal
from .format import FormatError, bagi_bulat_setengah_naik, parse_qty, parse_rupiah, QTY_SKALA
from .transaksi_config import ARAH_PINDAH, CARA, JENIS, JenisTransaksi

POLA_BARANG = ("penjualan", "pembelian_barang", "kerugian")


@dataclass
class ItemInput:
    barang_id: str
    qty: int
    harga: int = 0
    diskon: int = 0
    subtotal: int = 0


@dataclass
class InputTransaksi:
    jenis: str
    tanggal: date
    keterangan: str = ""
    pihak: str = ""
    cara: str = ""
    akun: str = ""
    arah: str = ""
    nominal: int = 0
    items: list[ItemInput] = field(default_factory=list)


class ValidasiError(Exception):
    """Isian tidak valid. `errors` berisi pesan per field (kunci: nama field atau item_N_field)."""

    def __init__(self, errors: dict[str, str]):
        super().__init__("Periksa kembali isian Anda.")
        self.errors = errors


def hitung_subtotal(qty: int, harga: int, diskon: int) -> int:
    """Subtotal bersih = jumlah x harga (dibulatkan ke rupiah) - diskon."""
    return bagi_bulat_setengah_naik(qty * harga, QTY_SKALA) - diskon


def _baca_item(i: int, baris: dict, j: JenisTransaksi, errors: dict[str, str]) -> ItemInput | None:
    barang_id = (baris.get("barang_id") or "").strip()
    qty_txt = (baris.get("qty") or "").strip()
    harga_txt = (baris.get("harga") or "").strip()
    diskon_txt = (baris.get("diskon") or "").strip()
    if not (barang_id or qty_txt or harga_txt or diskon_txt):
        return None
    if not barang_id:
        errors[f"item_{i}_barang"] = "Pilih barang."
    try:
        qty = parse_qty(qty_txt)
    except FormatError as e:
        errors[f"item_{i}_qty"] = str(e)
        qty = 0
    harga = diskon = 0
    if j.pola != "kerugian":
        try:
            harga = parse_rupiah(harga_txt)
        except FormatError as e:
            errors[f"item_{i}_harga"] = str(e)
        if diskon_txt:
            try:
                diskon = parse_rupiah(diskon_txt, boleh_nol=True)
            except FormatError as e:
                errors[f"item_{i}_diskon"] = str(e)
    if f"item_{i}_qty" in errors or f"item_{i}_harga" in errors or f"item_{i}_diskon" in errors or not barang_id:
        return None
    subtotal = hitung_subtotal(qty, harga, diskon) if j.pola != "kerugian" else 0
    if j.pola != "kerugian" and subtotal <= 0:
        errors[f"item_{i}_diskon"] = "Diskon tidak boleh sama dengan atau lebih besar dari harga."
        return None
    return ItemInput(barang_id, qty, harga, diskon, subtotal)


def validasi_form(form: dict) -> InputTransaksi:
    """Baca dan periksa isian form. Semua galat dikumpulkan sekaligus (ValidasiError)."""
    errors: dict[str, str] = {}
    kunci = (form.get("jenis") or "").strip()
    if kunci not in JENIS:
        raise ValidasiError({"jenis": "Pilih jenis transaksi."})
    j = JENIS[kunci]

    tanggal = parse_tanggal(form.get("tanggal", ""))
    if tanggal is None:
        errors["tanggal"] = "Isi tanggal transaksi dengan benar."
        tanggal = date(1970, 1, 1)

    keterangan = (form.get("keterangan") or "").strip()
    if len(keterangan) > 200:
        errors["keterangan"] = "Keterangan maksimal 200 karakter."
    elif not keterangan and j.pola not in ("penjualan", "pembelian_barang"):
        errors["keterangan"] = "Keterangan wajib diisi."
    elif keterangan and len(keterangan) < 3:
        errors["keterangan"] = "Keterangan minimal 3 karakter."

    pihak = (form.get("pihak") or "").strip()
    if len(pihak) > 80:
        errors["pihak"] = "Nama maksimal 80 karakter."

    cara = (form.get("cara") or "").strip()
    if j.cara:
        if cara not in j.cara:
            errors["cara"] = "Pilih salah satu cara."
        elif cara == "belum" and (form.get("akun") or "") != "6110":
            errors["cara"] = "Hanya gaji yang boleh dicatat belum dibayar."
    else:
        cara = ""

    akun = (form.get("akun") or "").strip()
    if j.akun_pilihan:
        if akun not in j.akun_pilihan:
            errors["akun"] = "Pilih salah satu."
    else:
        akun = ""

    arah = (form.get("arah") or "").strip()
    if j.pola == "pindah":
        if arah not in ARAH_PINDAH:
            errors["arah"] = "Pilih arah pindah dana."
    else:
        arah = ""

    nominal = 0
    if j.pola in POLA_BARANG:
        items: list[ItemInput] = []
        for i, baris in enumerate(form.get("items") or []):
            item = _baca_item(i, baris, j, errors)
            if item:
                items.append(item)
        if not items and not any(k.startswith("item_") for k in errors):
            errors["items"] = "Tambahkan minimal satu barang."
        if j.pola != "kerugian":
            nominal = sum(it.subtotal for it in items)
    else:
        items = []
        try:
            nominal = parse_rupiah(form.get("nominal", ""))
        except FormatError as e:
            errors["nominal"] = str(e)

    if errors:
        raise ValidasiError(errors)
    return InputTransaksi(kunci, tanggal, keterangan, pihak, cara, akun, arah, nominal, items)
