"""Akses data jurnal umum. Jurnal yang tersimpan tidak pernah diubah atau dihapus."""

from datetime import date

from ..db import new_id
from ..tanggal import date_to_db
from .jurnal_engine import BarisJurnal


def buat_jurnal(
    conn,
    period_id: str,
    nomor: str,
    tanggal: date,
    keterangan: str,
    jenis: str,
    baris: list[BarisJurnal],
    transaksi_id: str | None = None,
) -> str:
    """Simpan jurnal beserta barisnya. Pemeriksaan keseimbangan dilakukan pemanggil (periksa_jurnal)."""
    jurnal_id = new_id()
    conn.execute(
        "INSERT INTO JurnalUmum (id, nomor, periodId, transaksiId, tanggal, keterangan, jenis) "
        "VALUES (?,?,?,?,?,?,?)",
        (jurnal_id, nomor, period_id, transaksi_id, date_to_db(tanggal), keterangan, jenis),
    )
    for b in baris:
        conn.execute(
            "INSERT INTO JurnalLine (id, jurnalId, akunKode, debit, kredit) VALUES (?,?,?,?,?)",
            (new_id(), jurnal_id, b.akun, b.debit, b.kredit),
        )
    return jurnal_id
