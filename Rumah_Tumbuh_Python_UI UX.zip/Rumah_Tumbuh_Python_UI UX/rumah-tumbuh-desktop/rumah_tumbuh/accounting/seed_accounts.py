"""Isi dan rapikan akun standar tanpa menghapus akun tambahan pengguna."""
from ..db import transaction
from .coa import COA


class COAError(Exception):
    pass


def seed_accounts(conn) -> int:
    """Pastikan COA standar tersedia; cocokkan label legacy dan jaga akun yang sudah dipakai."""
    with transaction(conn):
        existing = {row["kode"]: row for row in conn.execute(
            "SELECT kode, nama, posSaldo, posLaporan FROM Account"
        ).fetchall()}
        for account in COA:
            row = existing.get(account["kode"])
            if row is None:
                conn.execute(
                    "INSERT INTO Account (kode, nama, posSaldo, posLaporan) VALUES (?, ?, ?, ?)",
                    (account["kode"], account["nama"], account["posSaldo"], account["posLaporan"]),
                )
                continue

            # Versi sebelumnya menamai beberapa akun dengan istilah berbeda. Label dapat
            # diperbarui tanpa mengubah saldo. Sisi normal/laporan hanya boleh diperbaiki
            # bila akun itu belum pernah dipakai dalam jurnal.
            if row["posSaldo"] != account["posSaldo"] or row["posLaporan"] != account["posLaporan"]:
                used = conn.execute(
                    "SELECT 1 FROM JurnalLine WHERE akunKode = ? LIMIT 1", (account["kode"],)
                ).fetchone()
                if used:
                    raise COAError(
                        f"Akun {account['kode']} berbeda dari COA standar dan sudah dipakai dalam jurnal. "
                        "Data tidak diubah. Hubungi pengelola sebelum memperbaiki COA."
                    )
            if (row["nama"], row["posSaldo"], row["posLaporan"]) != (
                account["nama"], account["posSaldo"], account["posLaporan"]
            ):
                conn.execute(
                    "UPDATE Account SET nama = ?, posSaldo = ?, posLaporan = ? WHERE kode = ?",
                    (account["nama"], account["posSaldo"], account["posLaporan"], account["kode"]),
                )

        # Akun tambahan/legacy yang tidak dipakai mesin transaksi tetap dipertahankan.
        return conn.execute("SELECT COUNT(*) FROM Account").fetchone()[0]
