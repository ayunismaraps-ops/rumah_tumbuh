"""Aplikasi web Rumah Tumbuh (Flask). Tahap 2 (akun, Dashboard) dan Tahap 3 (siklus akuntansi lengkap)."""

import json
import os

from flask import Flask, Response, g, redirect, render_template, request

from .auth.token import SESSION_COOKIE, SESSION_SECONDS, create_session
from .auth.users import DuplicateUsernameError, register_user, verify_credentials
from .auth.validation import ValidationError
from .config import database_path, load_env
from .accounting.format import format_qty, format_rupiah
from .dashboard import date_indonesia, rupiah
from .pages import daftar_blueprint
from .web import current_user, get_db, secret, session_user_id

# Halaman yang memerlukan sesi.
PROTECTED = (
    "/dashboard", "/transaksi", "/jurnal-umum", "/buku-besar", "/neraca-saldo",
    "/jurnal-penyesuaian", "/laporan", "/jurnal-penutup", "/kartu-persediaan", "/barang",
    "/invoice", "/periode", "/selesai", "/akun",
)  # fmt: skip


def create_app(config=None):
    load_env()
    app = Flask(__name__)
    app.url_map.strict_slashes = False
    app.config["PRODUCTION"] = os.environ.get("APP_ENV") == "production"
    if config:
        app.config.update(config)
    if "DATABASE" not in app.config:
        app.config["DATABASE"] = str(database_path())

    app.jinja_env.filters["rupiah"] = rupiah
    app.jinja_env.filters["rp"] = format_rupiah
    app.jinja_env.filters["tanggal"] = date_indonesia
    app.jinja_env.filters["qty"] = format_qty
    app.jinja_env.filters["tgl"] = lambda d: d.strftime("%d/%m/%Y") if d else ""
    for blueprint in daftar_blueprint():
        app.register_blueprint(blueprint)

    @app.teardown_appcontext
    def close_db(_error):
        conn = g.pop("db", None)
        if conn is not None:
            conn.close()

    def json_response(data, status=200):
        response = Response(json.dumps(data), status=status, mimetype="application/json")
        response.headers["Cache-Control"] = "no-store"
        return response

    def set_session_cookie(response, token, clear=False):
        response.set_cookie(
            SESSION_COOKIE,
            "" if clear else token,
            max_age=0 if clear else SESSION_SECONDS,
            path="/",
            httponly=True,
            samesite="Lax",
            secure=app.config["PRODUCTION"],
        )
        return response

    def is_protected(path):
        return any(path == p or path.startswith(p + "/") for p in PROTECTED)

    # ---------- middleware ----------
    @app.before_request
    def guard():
        path = request.path
        if path == "/":
            return redirect("/dashboard" if session_user_id() else "/login")
        if is_protected(path) and not session_user_id():
            response = redirect("/login")
            response.delete_cookie(SESSION_COOKIE, path="/")
            response.headers["Cache-Control"] = "no-store"
            return response
        if is_protected(path) and request.method not in ("GET", "HEAD", "OPTIONS"):
            origin = request.host_url.rstrip("/")
            if request.headers.get("Origin") != origin or request.headers.get("Sec-Fetch-Site") == "cross-site":
                return render_template("error.html", title=None), 403
        return None

    @app.after_request
    def no_store(response):
        if is_protected(request.path) or request.path in ("/login", "/register"):
            response.headers["Cache-Control"] = "no-store"
        return response

    # ---------- halaman autentikasi ----------
    @app.get("/login")
    def login_page():
        if current_user():
            return redirect("/dashboard")
        return render_template("login.html", title="Masuk", mode="login")

    @app.get("/register")
    def register_page():
        if current_user():
            return redirect("/dashboard")
        return render_template("register.html", title="Buat akun", mode="register")

    # ---------- API autentikasi ----------
    @app.route("/api/auth/<action>", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
    def auth_api(action):
        if request.method != "POST":
            return json_response({"error": "Metode tidak diizinkan."}, 405)
        if action not in ("login", "register", "logout"):
            return json_response({"error": "Halaman tidak tersedia."}, 404)
        origin = request.host_url.rstrip("/")
        if request.headers.get("Origin") != origin or request.headers.get("Sec-Fetch-Site") == "cross-site":
            return json_response({"error": "Permintaan tidak diizinkan."}, 403)
        if action == "logout":
            return set_session_cookie(json_response({"ok": True}), "", clear=True)
        if not (request.headers.get("Content-Type") or "").startswith("application/json"):
            return json_response({"error": "Format permintaan tidak valid."}, 415)
        body = request.get_data(as_text=True)
        if len(body) > 4096:
            return json_response({"error": "Isian terlalu panjang."}, 413)
        try:
            data = json.loads(body)
        except ValueError:
            return json_response({"error": "Format permintaan tidak valid."}, 400)
        try:
            # Validasi konfigurasi sebelum user/periode ditulis.
            signing_key = secret()
            if len(signing_key.encode("utf-8")) < 32:
                raise RuntimeError("Konfigurasi sesi belum tersedia.")
            conn = get_db()
            user = register_user(conn, data) if action == "register" else verify_credentials(conn, data)
            if not user:
                return json_response(
                    {"error": "Username atau sandi salah. Masukkan sandi kembali."}, 401
                )
            token = create_session(user["id"], signing_key)
            return set_session_cookie(json_response({"ok": True}), token)
        except ValidationError as error:
            return json_response({"error": "Periksa kembali isian Anda.", "fields": error.fields}, 400)
        except DuplicateUsernameError:
            return json_response(
                {"error": "Username sudah digunakan.", "fields": {"username": ["Pilih username yang lain."]}},
                409,
            )
        except Exception:
            return json_response(
                {"error": "Belum dapat memproses permintaan. Coba lagi atau hubungi pengelola."}, 503
            )

    # ---------- galat ----------
    @app.errorhandler(404)
    def not_found(_error):
        return render_template("not_found.html", title=None), 404

    @app.errorhandler(500)
    def server_error(_error):
        return render_template("error.html", title=None), 500

    return app
