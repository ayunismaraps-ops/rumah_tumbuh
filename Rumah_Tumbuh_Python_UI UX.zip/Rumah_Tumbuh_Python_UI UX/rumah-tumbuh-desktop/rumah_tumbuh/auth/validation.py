"""Validasi input login/registrasi (setara skema zod pada versi sebelumnya)."""

import re

_USERNAME_RE = re.compile(r"^[a-z0-9._]+$")
_NAMA_RE = re.compile(r"^[^<>]+$")
_WAJIB = "Wajib diisi."


class ValidationError(Exception):
    def __init__(self, fields):
        super().__init__("Periksa kembali isian Anda.")
        self.fields = fields


def _username(value, errors):
    if not isinstance(value, str):
        errors["username"] = [_WAJIB]
        return None
    value = value.strip().lower()
    issues = []
    if len(value) < 3:
        issues.append("Username minimal 3 karakter.")
    if len(value) > 32:
        issues.append("Username maksimal 32 karakter.")
    if not _USERNAME_RE.match(value):
        issues.append("Gunakan huruf, angka, titik, atau garis bawah.")
    if issues:
        errors["username"] = issues
        return None
    return value


def _sandi(value, errors):
    if not isinstance(value, str):
        errors["sandi"] = [_WAJIB]
        return None
    issues = []
    if len(value) < 8:
        issues.append("Sandi minimal 8 karakter.")
    if len(value.encode("utf-8")) > 72:
        issues.append("Sandi maksimal 72 byte; kurangi panjang sandi.")
    if issues:
        errors["sandi"] = issues
        return None
    return value


def _nama(value, errors):
    if not isinstance(value, str):
        errors["nama"] = [_WAJIB]
        return None
    value = value.strip()
    issues = []
    if len(value) < 2:
        issues.append("Nama minimal 2 karakter.")
    if len(value) > 80:
        issues.append("Nama maksimal 80 karakter.")
    if not _NAMA_RE.match(value):
        issues.append("Nama tidak boleh mengandung tanda < atau >.")
    if issues:
        errors["nama"] = issues
        return None
    return value


def parse_login(data):
    data = data if isinstance(data, dict) else {}
    errors = {}
    username = _username(data.get("username"), errors)
    sandi = _sandi(data.get("sandi"), errors)
    if errors:
        raise ValidationError(errors)
    return {"username": username, "sandi": sandi}


def parse_register(data):
    data = data if isinstance(data, dict) else {}
    errors = {}
    username = _username(data.get("username"), errors)
    sandi = _sandi(data.get("sandi"), errors)
    nama = _nama(data.get("nama"), errors)
    if errors:
        raise ValidationError(errors)
    return {"username": username, "sandi": sandi, "nama": nama}
