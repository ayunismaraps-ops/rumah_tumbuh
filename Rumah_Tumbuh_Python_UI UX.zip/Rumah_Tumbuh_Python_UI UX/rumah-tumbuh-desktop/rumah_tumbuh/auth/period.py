import calendar
from datetime import datetime, timedelta, timezone

JAKARTA = timezone(timedelta(hours=7))  # Asia/Jakarta tanpa DST; tidak butuh paket tzdata
BULAN = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember",
]  # fmt: skip


def current_month_jakarta(now: datetime):
    """Periode = bulan kalender Jakarta. Batas disimpan sebagai tengah malam Jakarta (UTC)."""
    local = now.astimezone(JAKARTA)
    year, month = local.year, local.month
    last_day = calendar.monthrange(year, month)[1]
    offset = timedelta(hours=7)
    return {
        "nama": f"{BULAN[month - 1]} {year}",
        "tanggalMulai": datetime(year, month, 1, tzinfo=timezone.utc) - offset,
        "tanggalAkhir": datetime(year, month, last_day, tzinfo=timezone.utc) - offset,
    }
