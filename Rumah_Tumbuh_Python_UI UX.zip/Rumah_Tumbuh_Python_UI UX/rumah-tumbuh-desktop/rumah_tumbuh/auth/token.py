"""Sesi JWT HS256 (8 jam) di cookie httpOnly."""

import os
from datetime import datetime, timezone

import jwt

SESSION_COOKIE = "rt_session"
SESSION_SECONDS = 8 * 60 * 60
ISSUER = "rumah-tumbuh"
AUDIENCE = "rumah-tumbuh-app"


def get_session_secret():
    secret = os.environ.get("JWT_SECRET")
    if not secret or len(secret.encode("utf-8")) < 32:
        raise RuntimeError("Konfigurasi sesi belum tersedia.")
    return secret


def _key(secret):
    key = secret.encode("utf-8")
    if len(key) < 32:
        raise RuntimeError("Kunci sesi terlalu pendek.")
    return key


def create_session(user_id, secret, now=None):
    now = now or datetime.now(timezone.utc)
    issued = int(now.timestamp())
    payload = {
        "sub": user_id,
        "iss": ISSUER,
        "aud": AUDIENCE,
        "iat": issued,
        "exp": issued + SESSION_SECONDS,
    }
    return jwt.encode(payload, _key(secret), algorithm="HS256")


def read_session(token, secret, now=None):
    """Kembalikan id pengguna bila token sah dan belum kedaluwarsa, selain itu None."""
    if not token:
        return None
    now = now or datetime.now(timezone.utc)
    try:
        payload = jwt.decode(
            token,
            _key(secret),
            algorithms=["HS256"],
            issuer=ISSUER,
            audience=AUDIENCE,
            # Kedaluwarsa diperiksa manual terhadap `now` agar dapat diuji.
            options={"require": ["sub", "iat", "exp"], "verify_exp": False, "verify_iat": False},
        )
        if now.timestamp() >= payload["exp"]:
            return None
        sub = payload.get("sub")
        return sub if isinstance(sub, str) and sub else None
    except Exception:
        return None
