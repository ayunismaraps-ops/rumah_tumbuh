import sqlite3
from datetime import datetime, timezone
from functools import lru_cache

from werkzeug.security import check_password_hash, generate_password_hash

from ..db import new_id, to_db, transaction
from .period import current_month_jakarta
from .validation import ValidationError, parse_login, parse_register


class DuplicateUsernameError(Exception):
    pass


@lru_cache(maxsize=1)
def _dummy_hash():
    # Dipakai agar waktu respons login tidak membedakan username ada/tidak ada.
    return generate_password_hash("rumah-tumbuh-dummy-comparison")


def register_user(conn, data, now=None):
    parsed = parse_register(data)
    now = now or datetime.now(timezone.utc)
    password_hash = generate_password_hash(parsed["sandi"])
    user_id = new_id()
    try:
        # IMMEDIATE: kunci tulis diambil dulu sebelum memeriksa "pengguna pertama".
        with transaction(conn):
            conn.execute(
                "INSERT INTO User (id, nama, username, passwordHash) VALUES (?, ?, ?, ?)",
                (user_id, parsed["nama"], parsed["username"], password_hash),
            )
            users = conn.execute("SELECT COUNT(*) FROM User").fetchone()[0]
            periods = conn.execute("SELECT COUNT(*) FROM Period").fetchone()[0]
            if users == 1 and periods == 0:
                period = current_month_jakarta(now)
                conn.execute(
                    "INSERT INTO Period (id, nama, tanggalMulai, tanggalAkhir, status) "
                    "VALUES (?, ?, ?, ?, 'AKTIF')",
                    (
                        new_id(),
                        period["nama"],
                        to_db(period["tanggalMulai"]),
                        to_db(period["tanggalAkhir"]),
                    ),
                )
    except sqlite3.IntegrityError as error:
        if "User.username" in str(error):
            raise DuplicateUsernameError() from error
        raise
    return {"id": user_id, "nama": parsed["nama"], "username": parsed["username"]}


def verify_credentials(conn, data):
    try:
        parsed = parse_login(data)
    except ValidationError:
        return None
    user = conn.execute(
        "SELECT id, nama, username, passwordHash FROM User WHERE username = ?",
        (parsed["username"],),
    ).fetchone()
    valid = check_password_hash(user["passwordHash"] if user else _dummy_hash(), parsed["sandi"])
    if valid and user:
        return {"id": user["id"], "nama": user["nama"], "username": user["username"]}
    return None
