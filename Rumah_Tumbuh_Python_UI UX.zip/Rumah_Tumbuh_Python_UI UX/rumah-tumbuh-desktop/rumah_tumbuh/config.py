"""Konfigurasi lokal: lokasi proyek, berkas .env, dan jalur database SQLite."""

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def load_env(path=None):
    """Baca .env sederhana (KEY="nilai"). Variabel yang sudah ada tidak ditimpa."""
    env_path = Path(path) if path else ROOT / ".env"
    if not env_path.exists():
        return
    for raw in env_path.read_text(encoding="utf8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        os.environ.setdefault(key, value)


def database_path(url=None):
    """Ubah DATABASE_URL (file:...) menjadi path. Path relatif dihitung dari folder db/."""
    url = url or os.environ.get("DATABASE_URL")
    if not url or not url.startswith("file:"):
        raise RuntimeError("Isi DATABASE_URL dengan alamat SQLite file: di .env.")
    raw = url[5:].split("?")[0]
    path = Path(raw)
    return path if path.is_absolute() else (ROOT / "db" / path).resolve()
