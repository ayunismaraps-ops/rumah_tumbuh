"""Penerap migrasi SQL bertahap dari folder db/migrations (tanpa menghapus data lama)."""

from pathlib import Path

from .config import ROOT
from .db import connect

MIGRATIONS_DIR = ROOT / "db" / "migrations"


def migrate(db_path, migrations_dir=MIGRATIONS_DIR):
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = connect(db_path)
    applied = []
    try:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS _migrations ("
            "name TEXT NOT NULL PRIMARY KEY, "
            "applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP)"
        )
        done = {row["name"] for row in conn.execute("SELECT name FROM _migrations")}
        for script in sorted(Path(migrations_dir).glob("*.sql")):
            if script.stem in done:
                continue
            sql = script.read_text(encoding="utf8")
            try:
                conn.executescript(
                    "BEGIN;\n"
                    + sql
                    + f"\nINSERT INTO _migrations (name) VALUES ('{script.stem}');\nCOMMIT;"
                )
            except Exception:
                if conn.in_transaction:
                    conn.execute("ROLLBACK")
                raise
            applied.append(script.stem)
    finally:
        conn.close()
    return applied
