"""Pembantu web bersama: koneksi database, sesi, navigasi, dan penampil halaman."""

from functools import wraps

from flask import abort, current_app, g, redirect, render_template, request

from .accounting.proses_transaksi import periode_aktif
from .auth.token import SESSION_COOKIE, get_session_secret, read_session
from .config import database_path  # noqa: F401  (dipakai app.py)
from .db import connect

# (kunci, ikon, nama, alamat)
NAV = [
    ("dashboard", "▦", "Dashboard", "/dashboard"),
    ("transaksi", "+", "Catat Transaksi", "/transaksi"),
    ("jurnal", "≡", "Jurnal Umum", "/jurnal-umum"),
    ("buku_besar", "▤", "Buku Besar", "/buku-besar"),
    ("neraca_saldo", "⊞", "Neraca Saldo", "/neraca-saldo"),
    ("penyesuaian", "⚖", "Penyesuaian", "/jurnal-penyesuaian"),
    ("laporan", "▥", "Laporan Keuangan", "/laporan"),
    ("penutup", "▣", "Jurnal Penutup", "/jurnal-penutup"),
    ("kartu", "☰", "Kartu Persediaan", "/kartu-persediaan"),
    ("barang", "❖", "Barang & Stok", "/barang"),
    ("invoice", "✉", "Invoice", "/invoice"),
    ("periode", "◷", "Periode", "/periode"),
    ("akun", "☷", "Daftar Akun", "/akun"),
]

STEPS = [
    "Catat Transaksi", "Jurnal Umum", "Buku Besar", "Neraca Saldo",
    "Penyesuaian", "Laporan", "Tutup Periode",
]


def secret() -> str:
    """Kunci penanda sesi. Konfigurasi eksplisit (dipakai tes) didahulukan dari variabel lingkungan."""
    cfg = current_app.config
    return cfg["JWT_SECRET"] if "JWT_SECRET" in cfg else get_session_secret()


def session_user_id():
    """ID pengguna dari cookie sesi, atau None."""
    try:
        return read_session(request.cookies.get(SESSION_COOKIE), secret())
    except Exception:
        return None


def get_db():
    """Koneksi database untuk satu permintaan (ditutup otomatis di akhir permintaan)."""
    if "db" not in g:
        g.db = connect(current_app.config["DATABASE"])
    return g.db


def current_user():
    """Pengguna yang sedang masuk (dict) atau None; selalu diperiksa ulang ke database."""
    if "user" not in g:
        user_id = session_user_id()
        row = None
        if user_id:
            row = get_db().execute("SELECT id, nama, username FROM User WHERE id = ?", (user_id,)).fetchone()
        g.user = dict(row) if row else None
    return g.user


def halaman(fungsi):
    """Dekorator: halaman memerlukan pengguna masuk; pengguna dikirim sebagai argumen pertama."""

    @wraps(fungsi)
    def bungkus(*args, **kwargs):
        user = current_user()
        if not user:
            return redirect("/login")
        return fungsi(user, *args, **kwargs)

    return bungkus


def render_halaman(template: str, user: dict, aktif: str, title: str, **konteks):
    """Render halaman aplikasi dengan sidebar, periode aktif, dan menu."""
    if "period" not in konteks:
        periode = periode_aktif(get_db())
        konteks["period"] = {"nama": periode["nama"]} if periode else None
    return render_template(template, user=user, aktif=aktif, title=title, nav=NAV, **konteks)


def ambil_atau_404(nilai):
    """Hentikan dengan 404 bila data tidak ada."""
    if nilai is None:
        abort(404)
    return nilai
