"""Paket aplikasi web Rumah Tumbuh yang ditampilkan di jendela desktop."""
from .app import create_app

__all__ = ["create_app"]
