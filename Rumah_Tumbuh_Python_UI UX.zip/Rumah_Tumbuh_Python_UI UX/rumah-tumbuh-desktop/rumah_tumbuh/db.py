"""Koneksi SQLite dan utilitas transaksi.

Tanggal disimpan sebagai teks ISO-8601 UTC (contoh 2026-10-31T17:00:00.000Z).
Nominal uang disimpan sebagai INTEGER (bilangan bulat Python), bukan float.
"""

import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone


def connect(path):
    # isolation_level=None: transaksi diatur manual agar BEGIN IMMEDIATE dapat dipakai.
    conn = sqlite3.connect(str(path), timeout=10, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def transaction(conn, immediate=True):
    """Transaksi atomik. IMMEDIATE mengambil kunci tulis lebih dulu (seperti pendaftaran pertama)."""
    conn.execute("BEGIN IMMEDIATE" if immediate else "BEGIN")
    try:
        yield conn
    except BaseException:
        conn.execute("ROLLBACK")
        raise
    else:
        conn.execute("COMMIT")


def new_id():
    return uuid.uuid4().hex


def to_db(value: datetime) -> str:
    value = value.astimezone(timezone.utc)
    return value.strftime("%Y-%m-%dT%H:%M:%S.") + f"{value.microsecond // 1000:03d}Z"


def from_db(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))
